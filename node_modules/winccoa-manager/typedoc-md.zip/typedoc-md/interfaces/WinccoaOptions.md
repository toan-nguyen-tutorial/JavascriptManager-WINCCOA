[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaOptions

# Interface: WinccoaOptions

## Properties

<a id="langidx" name="langidx"></a>

### langIdx

> **langIdx**: `number`

Property which applies only when [langTextFormat](WinccoaOptions.md#langtextformat) is `StringFixed`.
It holds the index of the project language to return for LangTexts.
Language index starts with 0 and default is `0`.

#### See

- [WinccoaManager.getOptions](../classes/WinccoaManager.md#getoptions)
- [WinccoaManager.setOptions](../classes/WinccoaManager.md#setoptions)
- [langTextFormat](WinccoaOptions.md#langtextformat)
- [WinccoaLangTextFormat](../enumerations/WinccoaLangTextFormat.md)

#### Example

```ts
import { WinccoaManager, WinccoaLangTextFormat } from 'winccoa-manager';
const winccoa = new WinccoaManager();

let isSuccess = false;
try {
  isSuccess = winccoa.setOptions({
    langTextFormat: WinccoaLangTextFormat.StringFixed,
    langIdx: 1
  });
} catch (exc) {
  console.error(exc);
}

if (isSuccess){
  try {
    let description = winccoa.dpGetDescription('ExampleDP_Rpt1.');
    console.info('DP description for 2nd project language: ' + description);
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/options.ts:109

***

<a id="langtextformat" name="langtextformat"></a>

### langTextFormat

> **langTextFormat**: [`WinccoaLangTextFormat`](../enumerations/WinccoaLangTextFormat.md)

Property which defines to which format a LangText will be converted.
Default is `StringActiveLanguage`.

#### See

- [WinccoaManager.getOptions](../classes/WinccoaManager.md#getoptions)
- [WinccoaManager.setOptions](../classes/WinccoaManager.md#setoptions)
- [WinccoaLangTextFormat](../enumerations/WinccoaLangTextFormat.md)

#### Example

```ts
let isSuccess = false;
try {
  isSuccess = winccoa.setOptions({
    langTextFormat: WinccoaLangTextFormat.StringActiveLanguage,
   });
} catch (exc) {
  console.error(exc);
}

if (isSuccess){
  try {
    let description = winccoa.dpGetDescription('ExampleDP_Rpt1.');
    console.info('DP description for active lang only: ' + description);
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/options.ts:74

***

<a id="longasbigint" name="longasbigint"></a>

### longAsBigInt

> **longAsBigInt**: `boolean`

Property which indicates whether long and unsigned long Variables should be returned as BigInts or numbers.
Default is `false`.

#### See

- [WinccoaManager.getOptions](../classes/WinccoaManager.md#getoptions)
- [WinccoaManager.setOptions](../classes/WinccoaManager.md#setoptions)

#### Source

winccoa-manager/lib/options.ts:117

***

<a id="userid" name="userid"></a>

### userId

> `readonly` **userId**: `number`

Read only property of the __userId__ with which manager was started

#### See

- [WinccoaManager.setUserId](../classes/WinccoaManager.md#setuserid)
- [WinccoaManager.getOptions](../classes/WinccoaManager.md#getoptions)

#### Source

winccoa-manager/lib/options.ts:45
