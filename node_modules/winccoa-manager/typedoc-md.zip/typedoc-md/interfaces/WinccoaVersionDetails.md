[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaVersionDetails

# Interface: WinccoaVersionDetails

Version information returned by [WinccoaManager.getVersionInfo](../classes/WinccoaManager.md#getversioninfo)

## Properties

<a id="api" name="api"></a>

### api

> **api**: `object`

API version details

<a id="version" name="version"></a>

#### version

> **version**: `number`

API version number, e.g. `7`

#### Source

winccoa-manager/lib/binding.ts:445

***

<a id="winccoa" name="winccoa"></a>

### winccoa

> **winccoa**: `object`

WinCC OA version details

<a id="display" name="display"></a>

#### display

> **display**: `string`

WinCC OA version for display purposes, e.g. `'3.20'`

<a id="major" name="major"></a>

#### major

> **major**: `number`

WinCC OA major version number, e.g. `3`

<a id="minor" name="minor"></a>

#### minor

> **minor**: `number`

WinCC OA minor version number, e.g. `20`

<a id="numeric" name="numeric"></a>

#### numeric

> **numeric**: `number`

WinCC OA version as an integer, e.g. `320000`

<a id="numeric_full" name="numeric_full"></a>

#### numeric\_full

> **numeric\_full**: `number`

WinCC OA version number including patch as an integer, e.g. `320011`

<a id="patch" name="patch"></a>

#### patch

> **patch**: `number`

WinCC OA patch number, e.g. `4`

<a id="platform" name="platform"></a>

#### platform

> **platform**: `string`

WinCC OA platform info , e.g. `'Windows AMD64'`

<a id="revision" name="revision"></a>

#### revision

> **revision**: `number`

WinCC OA revision number, e.g. `0`

<a id="version-1" name="version-1"></a>

#### version

> **version**: `string`

WinCC OA version, e.g. `'3.20'`

#### Source

winccoa-manager/lib/binding.ts:451
