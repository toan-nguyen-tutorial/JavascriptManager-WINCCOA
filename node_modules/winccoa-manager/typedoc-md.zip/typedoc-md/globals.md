[**winccoa-manager**](README.md) • **Docs**

***

# winccoa-manager

## Enumerations

- [WinccoaConnectUpdateType](enumerations/WinccoaConnectUpdateType.md)
- [WinccoaCtrlType](enumerations/WinccoaCtrlType.md)
- [WinccoaElementType](enumerations/WinccoaElementType.md)
- [WinccoaLangTextFormat](enumerations/WinccoaLangTextFormat.md)
- [WinccoaSecurityEventId](enumerations/WinccoaSecurityEventId.md)

## Classes

- [WinccoaAlertTime](classes/WinccoaAlertTime.md)
- [WinccoaCtrlScript](classes/WinccoaCtrlScript.md)
- [WinccoaError](classes/WinccoaError.md)
- [WinccoaManager](classes/WinccoaManager.md)

## Interfaces

- [WinccoaOptions](interfaces/WinccoaOptions.md)
- [WinccoaVersionDetails](interfaces/WinccoaVersionDetails.md)

## Type Aliases

- [WinccoaDpConnectCallback](type-aliases/WinccoaDpConnectCallback.md)
- [WinccoaDpQueryConnectCallback](type-aliases/WinccoaDpQueryConnectCallback.md)

## Functions

- [delay](functions/delay.md)
