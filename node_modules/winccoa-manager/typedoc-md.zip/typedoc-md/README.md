**winccoa-manager** • [**Docs**](globals.md)

***

# API documentation for WinCC OA JavaScript Manager for Node.js&#174;

The main API class is [WinccoaManager](classes/WinccoaManager.md), start your exploration there.

> **IMPORTANT**
>
> Most code examples in this documentation are not complete, but only
> snippets that show how to use a method or type. Note that the methods
> described in this documentation must be **called from code inside a
> method or function** to prevent unexpected or undefined behavior.

> **NOTE**
>
> If a code example does not contain an `import` statement, it is assumed that an
> instance of [WinccoaManager](classes/WinccoaManager.md) has been created and can be accessed with
> the constant `winccoa`, e. g.:
>
> ```ts
> import { WinccoaManager } from 'winccoa-manager';
> const winccoa = new WinccoaManager();
> ```

> **NOTE**
>
> Almost all examples in this API documentation are given in TypeScript, but it is
> easy to convert them to JavaScript, if required:
>
> 1. Replace `import { ... } from 'winccoa-manager'` with
>    `const { ... } = require('winccoa-manager')`.
> 2. Remove all explicit type definitions (e. g. replace `name: number` with `name`).
> 3. Remove all type conversions that are using the keyword `as`.
> 4. Do not use the question mark for optional parameters.
>
> Examples given both in TypeScript and JavaScript that illustrate all these points
> can be found In the documentation for [WinccoaDpConnectCallback](type-aliases/WinccoaDpConnectCallback.md),
> [WinccoaError](classes/WinccoaError.md) and [WinccoaAlertTime](classes/WinccoaAlertTime.md).
