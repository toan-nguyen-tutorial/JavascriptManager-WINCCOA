[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaCtrlType

# Enumeration: WinccoaCtrlType

Enumerates CTRL data types that can be used as parameters for CTRL function calls.
The enumerated values have exactly the same name as the corresponding CTRL type
and therefore start with a lowercase letter.

## See

[WinccoaCtrlScript.start](../classes/WinccoaCtrlScript.md#start)

## Enumeration Members

<a id="atime" name="atime"></a>

### atime

> **atime**: `2424832`

`atime` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:217

***

<a id="bit32" name="bit32"></a>

### bit32

> **bit32**: `589824`

`bit32` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:181

***

<a id="bit64" name="bit64"></a>

### bit64

> **bit64**: `4980736`

`bit64` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:241

***

<a id="bool" name="bool"></a>

### bool

> **bool**: `262144`

`bool` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:169

***

<a id="char" name="char"></a>

### char

> **char**: `655360`

`char` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:183

***

<a id="double" name="double"></a>

### double

> **double**: `458752`

`double` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:177

***

<a id="dyn_atime" name="dyn_atime"></a>

### dyn\_atime

> **dyn\_atime**: `2490368`

`dyn_atime` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:219

***

<a id="dyn_bit32" name="dyn_bit32"></a>

### dyn\_bit32

> **dyn\_bit32**: `1245184`

`dyn_32bit` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:197

***

<a id="dyn_bit64" name="dyn_bit64"></a>

### dyn\_bit64

> **dyn\_bit64**: `5046272`

`dyn_bit6` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:243

***

<a id="dyn_bool" name="dyn_bool"></a>

### dyn\_bool

> **dyn\_bool**: `917504`

`dyn_bool` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:187

***

<a id="dyn_char" name="dyn_char"></a>

### dyn\_char

> **dyn\_char**: `1310720`

`dyn_char` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:199

***

<a id="dyn_dyn_atime" name="dyn_dyn_atime"></a>

### dyn\_dyn\_atime

> **dyn\_dyn\_atime**: `2555904`

`dyn_dyn_atime` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:221

***

<a id="dyn_dyn_bit32" name="dyn_dyn_bit32"></a>

### dyn\_dyn\_bit32

> **dyn\_dyn\_bit32**: `2097152`

`dyn_dyn_32bit` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:213

***

<a id="dyn_dyn_bit64" name="dyn_dyn_bit64"></a>

### dyn\_dyn\_bit64

> **dyn\_dyn\_bit64**: `5111808`

`dyn_dyn_bit64` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:245

***

<a id="dyn_dyn_bool" name="dyn_dyn_bool"></a>

### dyn\_dyn\_bool

> **dyn\_dyn\_bool**: `1769472`

`dyn_dyn_bool` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:203

***

<a id="dyn_dyn_char" name="dyn_dyn_char"></a>

### dyn\_dyn\_char

> **dyn\_dyn\_char**: `2162688`

`dyn_dyn_char` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:215

***

<a id="dyn_dyn_float" name="dyn_dyn_float"></a>

### dyn\_dyn\_float

> **dyn\_dyn\_float**: `1966080`

`dyn_dyn_float` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:209

***

<a id="dyn_dyn_int" name="dyn_dyn_int"></a>

### dyn\_dyn\_int

> **dyn\_dyn\_int**: `1835008`

`dyn_dyn_int` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:205

***

<a id="dyn_dyn_langstring" name="dyn_dyn_langstring"></a>

### dyn\_dyn\_langString

> **dyn\_dyn\_langString**: `2752512`

`dyn_dyn_langString variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:227

***

<a id="dyn_dyn_long" name="dyn_dyn_long"></a>

### dyn\_dyn\_long

> **dyn\_dyn\_long**: `4718592`

`dyn_dyn_long` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:233

***

<a id="dyn_dyn_string" name="dyn_dyn_string"></a>

### dyn\_dyn\_string

> **dyn\_dyn\_string**: `2031616`

`dyn_dyn_string` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:211

***

<a id="dyn_dyn_time" name="dyn_dyn_time"></a>

### dyn\_dyn\_time

> **dyn\_dyn\_time**: `1703936`

`dyn_dyn_time` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:201

***

<a id="dyn_dyn_uint" name="dyn_dyn_uint"></a>

### dyn\_dyn\_uint

> **dyn\_dyn\_uint**: `1900544`

`dyn_dyn_uint` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:207

***

<a id="dyn_dyn_ulong" name="dyn_dyn_ulong"></a>

### dyn\_dyn\_ulong

> **dyn\_dyn\_ulong**: `4915200`

`dyn_dyn_ulong` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:239

***

<a id="dyn_float" name="dyn_float"></a>

### dyn\_float

> **dyn\_float**: `1114112`

`dyn_float` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:193

***

<a id="dyn_int" name="dyn_int"></a>

### dyn\_int

> **dyn\_int**: `983040`

`dyn_int` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:189

***

<a id="dyn_langstring" name="dyn_langstring"></a>

### dyn\_langString

> **dyn\_langString**: `2686976`

`dyn_langString` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:225

***

<a id="dyn_long" name="dyn_long"></a>

### dyn\_long

> **dyn\_long**: `4653056`

`dyn_long` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:231

***

<a id="dyn_string" name="dyn_string"></a>

### dyn\_string

> **dyn\_string**: `1179648`

`dyn_string` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:195

***

<a id="dyn_time" name="dyn_time"></a>

### dyn\_time

> **dyn\_time**: `851968`

`dyn_time` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:185

***

<a id="dyn_uint" name="dyn_uint"></a>

### dyn\_uint

> **dyn\_uint**: `1048576`

`dyn_uint` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:191

***

<a id="dyn_ulong" name="dyn_ulong"></a>

### dyn\_ulong

> **dyn\_ulong**: `4849664`

`dyn_ulong` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:237

***

<a id="float" name="float"></a>

### float

> **float**: `458752`

`float` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:175

***

<a id="int" name="int"></a>

### int

> **int**: `327680`

`int` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:171

***

<a id="langstring" name="langstring"></a>

### langString

> **langString**: `2621440`

`langString` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:223

***

<a id="long" name="long"></a>

### long

> **long**: `4587520`

`long` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:229

***

<a id="string" name="string"></a>

### string

> **string**: `524288`

`string` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:179

***

<a id="time" name="time"></a>

### time

> **time**: `196608`

`time` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:167

***

<a id="uint" name="uint"></a>

### uint

> **uint**: `393216`

`uint` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:173

***

<a id="ulong" name="ulong"></a>

### ulong

> **ulong**: `4784128`

`ulong` variable type

#### Source

winccoa-manager/lib/ctrl-types.ts:235
