[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaElementType

# Enumeration: WinccoaElementType

Enumerates the type of a data point element, as returned by
[WinccoaManager.dpElementType](../classes/WinccoaManager.md#dpelementtype).

## See

[WinccoaManager.dpElementType](../classes/WinccoaManager.md#dpelementtype).

## Enumeration Members

<a id="bit32" name="bit32"></a>

### Bit32

> **Bit32**: `24`

bit pattern

#### Source

winccoa-manager/lib/binding.ts:55

***

<a id="bit32struct" name="bit32struct"></a>

### Bit32Struct

> **Bit32Struct**: `16`

bit pattern structure

#### Source

winccoa-manager/lib/binding.ts:58

***

<a id="bit64" name="bit64"></a>

### Bit64

> **Bit64**: `50`

bit pattern

#### Source

winccoa-manager/lib/binding.ts:61

***

<a id="bit64struct" name="bit64struct"></a>

### Bit64Struct

> **Bit64Struct**: `52`

bit pattern structure

#### Source

winccoa-manager/lib/binding.ts:64

***

<a id="blob" name="blob"></a>

### Blob

> **Blob**: `46`

blob (binary large object)

#### Source

winccoa-manager/lib/binding.ts:67

***

<a id="blobstruct" name="blobstruct"></a>

### BlobStruct

> **BlobStruct**: `47`

blob structure

#### Source

winccoa-manager/lib/binding.ts:70

***

<a id="bool" name="bool"></a>

### Bool

> **Bool**: `23`

bit

#### Source

winccoa-manager/lib/binding.ts:73

***

<a id="boolstruct" name="boolstruct"></a>

### BoolStruct

> **BoolStruct**: `15`

bit structure

#### Source

winccoa-manager/lib/binding.ts:76

***

<a id="char" name="char"></a>

### Char

> **Char**: `19`

character

#### Source

winccoa-manager/lib/binding.ts:79

***

<a id="charstruct" name="charstruct"></a>

### CharStruct

> **CharStruct**: `11`

character structure

#### Source

winccoa-manager/lib/binding.ts:82

***

<a id="dpid" name="dpid"></a>

### Dpid

> **Dpid**: `27`

DP-Identifier

#### Source

winccoa-manager/lib/binding.ts:85

***

<a id="dpidstruct" name="dpidstruct"></a>

### DpidStruct

> **DpidStruct**: `39`

label structure

#### Source

winccoa-manager/lib/binding.ts:88

***

<a id="dynbit32" name="dynbit32"></a>

### DynBit32

> **DynBit32**: `8`

dynamic array for bit pattern

#### Source

winccoa-manager/lib/binding.ts:91

***

<a id="dynbit32struct" name="dynbit32struct"></a>

### DynBit32Struct

> **DynBit32Struct**: `35`

dynamic bit-pattern array structure

#### Source

winccoa-manager/lib/binding.ts:94

***

<a id="dynbit64" name="dynbit64"></a>

### DynBit64

> **DynBit64**: `51`

dynamic array for bit pattern

#### Source

winccoa-manager/lib/binding.ts:97

***

<a id="dynbit64struct" name="dynbit64struct"></a>

### DynBit64Struct

> **DynBit64Struct**: `53`

dynamic bit-pattern array structure

#### Source

winccoa-manager/lib/binding.ts:100

***

<a id="dynblob" name="dynblob"></a>

### DynBlob

> **DynBlob**: `48`

dynamic blob

#### Source

winccoa-manager/lib/binding.ts:103

***

<a id="dynblobstruct" name="dynblobstruct"></a>

### DynBlobStruct

> **DynBlobStruct**: `49`

dynamic blob structure

#### Source

winccoa-manager/lib/binding.ts:106

***

<a id="dynbool" name="dynbool"></a>

### DynBool

> **DynBool**: `7`

dynamic bit array

#### Source

winccoa-manager/lib/binding.ts:109

***

<a id="dynboolstruct" name="dynboolstruct"></a>

### DynBoolStruct

> **DynBoolStruct**: `34`

dynamic bit array structure

#### Source

winccoa-manager/lib/binding.ts:112

***

<a id="dynchar" name="dynchar"></a>

### DynChar

> **DynChar**: `3`

dynamic character array

#### Source

winccoa-manager/lib/binding.ts:115

***

<a id="dyncharstruct" name="dyncharstruct"></a>

### DynCharStruct

> **DynCharStruct**: `30`

dynamic character array structure

#### Source

winccoa-manager/lib/binding.ts:118

***

<a id="dyndpid" name="dyndpid"></a>

### DynDpid

> **DynDpid**: `29`

dynamic DP-Identifier array

#### Source

winccoa-manager/lib/binding.ts:121

***

<a id="dyndpidstruct" name="dyndpidstruct"></a>

### DynDpidStruct

> **DynDpidStruct**: `38`

dynamic DP-Identifier array structure

#### Source

winccoa-manager/lib/binding.ts:124

***

<a id="dynfloat" name="dynfloat"></a>

### DynFloat

> **DynFloat**: `6`

dynamic number array for floating decimal point

#### Source

winccoa-manager/lib/binding.ts:127

***

<a id="dynfloatstruct" name="dynfloatstruct"></a>

### DynFloatStruct

> **DynFloatStruct**: `33`

dynamic number structure for floating decimal point

#### Source

winccoa-manager/lib/binding.ts:130

***

<a id="dynint" name="dynint"></a>

### DynInt

> **DynInt**: `5`

dynamic integer array

#### Source

winccoa-manager/lib/binding.ts:133

***

<a id="dynintstruct" name="dynintstruct"></a>

### DynIntStruct

> **DynIntStruct**: `32`

dynamic integer structure

#### Source

winccoa-manager/lib/binding.ts:136

***

<a id="dynlangstring" name="dynlangstring"></a>

### DynLangString

> **DynLangString**: `44`

multilingual dynamic text array

#### Source

winccoa-manager/lib/binding.ts:139

***

<a id="dynlangstringstruct" name="dynlangstringstruct"></a>

### DynLangStringStruct

> **DynLangStringStruct**: `45`

multilingual dynamic text structure

#### Source

winccoa-manager/lib/binding.ts:142

***

<a id="dynlong" name="dynlong"></a>

### DynLong

> **DynLong**: `55`

dynamic array of Integer values (64 bit)

#### Source

winccoa-manager/lib/binding.ts:145

***

<a id="dynlongstruct" name="dynlongstruct"></a>

### DynLongStruct

> **DynLongStruct**: `57`

dynamic number structure for integer value (64 bit)

#### Source

winccoa-manager/lib/binding.ts:148

***

<a id="dynstring" name="dynstring"></a>

### DynString

> **DynString**: `9`

dynamic text array

#### Source

winccoa-manager/lib/binding.ts:151

***

<a id="dynstringstruct" name="dynstringstruct"></a>

### DynStringStruct

> **DynStringStruct**: `36`

dynamic text-array structure

#### Source

winccoa-manager/lib/binding.ts:154

***

<a id="dyntime" name="dyntime"></a>

### DynTime

> **DynTime**: `10`

dynamic time array

#### Source

winccoa-manager/lib/binding.ts:157

***

<a id="dyntimestruct" name="dyntimestruct"></a>

### DynTimeStruct

> **DynTimeStruct**: `37`

dynamic time array structure

#### Source

winccoa-manager/lib/binding.ts:160

***

<a id="dynuint" name="dynuint"></a>

### DynUInt

> **DynUInt**: `4`

dynamic array of positive whole numbers

#### Source

winccoa-manager/lib/binding.ts:163

***

<a id="dynuintstruct" name="dynuintstruct"></a>

### DynUIntStruct

> **DynUIntStruct**: `31`

dynamic array of positive integers

#### Source

winccoa-manager/lib/binding.ts:166

***

<a id="dynulong" name="dynulong"></a>

### DynULong

> **DynULong**: `59`

dynamic array of Positive integer values (64 bit)

#### Source

winccoa-manager/lib/binding.ts:169

***

<a id="dynulongstruct" name="dynulongstruct"></a>

### DynULongStruct

> **DynULongStruct**: `61`

dynamic number structure for positive integer value (64 bit)

#### Source

winccoa-manager/lib/binding.ts:172

***

<a id="float" name="float"></a>

### Float

> **Float**: `22`

floating point system

#### Source

winccoa-manager/lib/binding.ts:175

***

<a id="floatstruct" name="floatstruct"></a>

### FloatStruct

> **FloatStruct**: `14`

number structure for floating decimal point

#### Source

winccoa-manager/lib/binding.ts:178

***

<a id="int" name="int"></a>

### Int

> **Int**: `21`

integer

#### Source

winccoa-manager/lib/binding.ts:181

***

<a id="intstruct" name="intstruct"></a>

### IntStruct

> **IntStruct**: `13`

integer structure

#### Source

winccoa-manager/lib/binding.ts:184

***

<a id="langstring" name="langstring"></a>

### LangString

> **LangString**: `42`

description

#### Source

winccoa-manager/lib/binding.ts:187

***

<a id="langstringstruct" name="langstringstruct"></a>

### LangStringStruct

> **LangStringStruct**: `43`

description structure

#### Source

winccoa-manager/lib/binding.ts:190

***

<a id="long" name="long"></a>

### Long

> **Long**: `54`

Integer value (64 bit)

#### Source

winccoa-manager/lib/binding.ts:193

***

<a id="longstruct" name="longstruct"></a>

### LongStruct

> **LongStruct**: `56`

structure for integer value (64 bit)

#### Source

winccoa-manager/lib/binding.ts:196

***

<a id="string" name="string"></a>

### String

> **String**: `25`

text

#### Source

winccoa-manager/lib/binding.ts:199

***

<a id="stringstruct" name="stringstruct"></a>

### StringStruct

> **StringStruct**: `17`

text structure

#### Source

winccoa-manager/lib/binding.ts:202

***

<a id="struct" name="struct"></a>

### Struct

> **Struct**: `1`

structure

#### Source

winccoa-manager/lib/binding.ts:205

***

<a id="time" name="time"></a>

### Time

> **Time**: `26`

time

#### Source

winccoa-manager/lib/binding.ts:208

***

<a id="timestruct" name="timestruct"></a>

### TimeStruct

> **TimeStruct**: `18`

time structure

#### Source

winccoa-manager/lib/binding.ts:211

***

<a id="typeref" name="typeref"></a>

### Typeref

> **Typeref**: `41`

data point type reference

#### Source

winccoa-manager/lib/binding.ts:214

***

<a id="uint" name="uint"></a>

### UInt

> **UInt**: `20`

unsigned integer

#### Source

winccoa-manager/lib/binding.ts:217

***

<a id="uintstruct" name="uintstruct"></a>

### UIntStruct

> **UIntStruct**: `12`

structure of unsigned integers

#### Source

winccoa-manager/lib/binding.ts:220

***

<a id="ulong" name="ulong"></a>

### ULong

> **ULong**: `58`

Positive integer value (64 bit)

#### Source

winccoa-manager/lib/binding.ts:223

***

<a id="ulongstruct" name="ulongstruct"></a>

### ULongStruct

> **ULongStruct**: `60`

structure for positive integer value (64 bit)

#### Source

winccoa-manager/lib/binding.ts:226
