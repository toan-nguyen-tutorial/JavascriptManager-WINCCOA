[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaSecurityEventId

# Enumeration: WinccoaSecurityEventId

Enumerates the security events that can be reported from this manager.

## See

- [WinccoaManager.securityEvent](../classes/WinccoaManager.md#securityevent)

## Enumeration Members

<a id="portopened" name="portopened"></a>

### PortOpened

> **PortOpened**: `1`

Server port has been opened. Required additional parameters when calling
 [WinccoaManager.securityEvent](../classes/WinccoaManager.md#securityevent):
- args[0] - port: number
- args[1] - protocolDetails: string (e.g. `'https://'`)

#### Source

winccoa-manager/lib/binding.ts:45

***

<a id="unknown" name="unknown"></a>

### Unknown

> **Unknown**: `0`

Unknown ID - do not use

#### Source

winccoa-manager/lib/binding.ts:39
