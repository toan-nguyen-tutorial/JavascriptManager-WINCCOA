[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaLangTextFormat

# Enumeration: WinccoaLangTextFormat

Enumerates the formats in which a multi-language strings (CTRL `langString`)
can be returned by the API.

## See

- [WinccoaOptions.langIdx](../interfaces/WinccoaOptions.md#langidx)
- [WinccoaOptions.langTextFormat](../interfaces/WinccoaOptions.md#langtextformat)

## Enumeration Members

<a id="array" name="array"></a>

### Array

> **Array**: `3`

Multi-language strings will be returned as an array, sorted by
language IDs.

#### Example

```ts
['Deutscher Text', 'English text']
```

#### Source

winccoa-manager/lib/options.ts:36

***

<a id="object" name="object"></a>

### Object

> **Object**: `2`

Multi-language strings will be returned as an object, locale names
are used as property names.

#### Example

```ts
{ 'de_AT.utf8': 'Deutscher Text', 'en_US.utf8': 'English text' }
```

#### Source

winccoa-manager/lib/options.ts:27

***

<a id="stringactivelanguage" name="stringactivelanguage"></a>

### StringActiveLanguage

> **StringActiveLanguage**: `0`

Multi-language strings will be returned as a simple sting in the
current language.

#### Source

winccoa-manager/lib/options.ts:13

***

<a id="stringfixed" name="stringfixed"></a>

### StringFixed

> **StringFixed**: `1`

Multi-language strings will be returned as a single string in the
 language defined with option [WinccoaOptions.langIdx](../interfaces/WinccoaOptions.md#langidx).

#### Source

winccoa-manager/lib/options.ts:18
