[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaConnectUpdateType

# Enumeration: WinccoaConnectUpdateType

Enumerates the type of updates received by connect callbacks.

## See

- [WinccoaDpConnectCallback](../type-aliases/WinccoaDpConnectCallback.md)
- [WinccoaDpQueryConnectCallback](../type-aliases/WinccoaDpQueryConnectCallback.md)

## Enumeration Members

<a id="answer" name="answer"></a>

### Answer

> **Answer**: `1`

Initial update with current values.

#### Source

winccoa-manager/lib/binding.ts:27

***

<a id="normal" name="normal"></a>

### Normal

> **Normal**: `0`

Normal update after value changes.

#### Source

winccoa-manager/lib/binding.ts:24

***

<a id="refresh" name="refresh"></a>

### Refresh

> **Refresh**: `2`

Refresh update after REDU switch or DIST connection.

#### Source

winccoa-manager/lib/binding.ts:30
