[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / delay

# Function: delay()

<a id="undefined" name="undefined"></a>

> **delay**(`seconds`, `milliseconds`): `Promise`\<`unknown`\>

Convenience method for waiting a given time period (in seconds plus optional milliseconds).
Implements the same interface as CTRL function delay().

## Parameters

• **seconds**: `number`

Seconds to wait before continuing.

• **milliseconds**: `number`= `0`

Milliseconds to wait before continuing.

## Returns

`Promise`\<`unknown`\>

Promise - will be resolved after given time interval is elapsed.

## See

- [CTRL function `delay()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/delay.html?hl=delay)

## Example

```ts
import { WinccoaManager, delay } from 'winccoa-manager';
const winccoa = new WinccoaManager();

await delay(1, 500); // wait for 1.5 seconds
```

## Source

winccoa-manager/lib/tools.ts:18
