[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaDpConnectCallback

# Type alias: WinccoaDpConnectCallback()

<a id="undefined" name="undefined"></a>

> **WinccoaDpConnectCallback**: (`dpeNames`, `values`, `type`, `error`?) => `void` \| `Promise`\<`void`\>

Type of callbacks from [WinccoaManager.dpConnect](../classes/WinccoaManager.md#dpconnect).

## See

- [WinccoaManager.dpConnect](../classes/WinccoaManager.md#dpconnect)
- [WinccoaConnectUpdateType](../enumerations/WinccoaConnectUpdateType.md)

## Example

#### TypeScript
```ts
import {
  WinccoaManager,
  WinccoaConnectUpdateType,
  WinccoaError
} from 'winccoa-manager';
const winccoa = new WinccoaManager();

function connectCB(
  names: string[],
  values: unknown[],
  type: WinccoaConnectUpdateType,
  error?: WinccoaError
) {
  if (error) {
    console.log(error);
    return;
  }

  if (type == WinccoaConnectUpdateType.Answer)
    console.warn('--- Initial update ---');

  for (let i = 0; i < names.length; i++)
    console.info(`[${i}] '${names[i]}' : ${values[i]}`);
}

function connect() {
  let id = -1;
  try {
    id = winccoa.dpConnect(
      connectCB,
      ['ExampleDP_Arg1.', 'ExampleDP_Arg2.'],
      true
    );
  } catch (exc) {
   console.error(exc);
  }
}
```
#### JavaScript
```js
const { WinccoaManager, WinccoaConnectUpdateType } = require('winccoa-manager');
const winccoa = new WinccoaManager();

function connectCB(names, values, type, error) {
  if (error) {
    console.log(error);
    return;
  }

  if (type == WinccoaConnectUpdateType.Answer)
    console.warn('--- Initial update ---');

  for (let i = 0; i < names.length; i++)
    console.info(`[${i}] '${names[i]}' : ${values[i]}`);
}

function connect() {
  let id = -1;
  try {
    id = winccoa.dpConnect(
      connectCB,
      ['ExampleDP_Arg1.', 'ExampleDP_Arg2.'],
      true,
    );
  } catch (exc) {
    console.error(exc);
  }
}
```

## Parameters

• **dpeNames**: `string`[]

Names of the updated datapoint elements. Will always be an array, also
                if it contains only one name.

• **values**: `unknown`[]

Updated values. Will always be an array, also if it contains only one value.

• **type**: [`WinccoaConnectUpdateType`](../enumerations/WinccoaConnectUpdateType.md)

Type of the update.

• **error?**: [`WinccoaError`](../classes/WinccoaError.md)

In case of an error, the other parameters are undefined and this parameter will
             contain error information.

## Returns

`void` \| `Promise`\<`void`\>

## Source

winccoa-manager/lib/binding.ts:312
