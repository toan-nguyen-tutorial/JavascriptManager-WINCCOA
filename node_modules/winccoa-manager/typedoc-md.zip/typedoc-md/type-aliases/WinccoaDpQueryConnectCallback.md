[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaDpQueryConnectCallback

# Type alias: WinccoaDpQueryConnectCallback()

<a id="undefined" name="undefined"></a>

> **WinccoaDpQueryConnectCallback**: (`values`, `type`, `error`?) => `void` \| `Promise`\<`void`\>

Type of callbacks from [WinccoaManager.dpQueryConnectAll](../classes/WinccoaManager.md#dpqueryconnectall) and [WinccoaManager.dpQueryConnectSingle](../classes/WinccoaManager.md#dpqueryconnectsingle).

## See

- [WinccoaManager.dpQueryConnectAll](../classes/WinccoaManager.md#dpqueryconnectall)
- [WinccoaManager.dpQueryConnectSingle](../classes/WinccoaManager.md#dpqueryconnectsingle)
- [WinccoaConnectUpdateType](../enumerations/WinccoaConnectUpdateType.md)

## Example

```ts
import {
  WinccoaManager,
  WinccoaConnectUpdateType,
  WinccoaError
} from 'winccoa-manager';
const winccoa = new WinccoaManager();

function  queryConnectCB (
  values: unknown[][],
  type: WinccoaConnectUpdateType,
  error?: WinccoaError,
) {
  if (error) {
    console.error(error);
    return;
  }

  if (type == WinccoaConnectUpdateType.Answer)
    console.warn('--- Initial update ---');

  // ignore line with index 0 (it's a header) and start with index 1
  for (let i = 1; i < values.length; i++) {
    console.info(`DPE = '%s', value = %s`, ...values[i]);
  }
};

function connect() {
  let id = -1;
  try {
    id = winccoa.dpQueryConnectSingle(
      queryConnectCB,
      true,
      "SELECT '_original.._value' FROM 'ExampleDP_Arg*'"
    );
  } catch (exc) {
    console.error(exc);
  }
}
 ```
#### Connecting with user data
To pass user data to the callback, it is not necessary to use a different
API method. Instead, an arrow function can be used to include user data
whenever a callback is called. The same pattern can also be used for
other callbacks, e. g. from [WinccoaManager.dpConnect](../classes/WinccoaManager.md#dpconnect)
```ts
import {
  WinccoaManager,
  WinccoaConnectUpdateType,
  WinccoaError
} from 'winccoa-manager';
const winccoa = new WinccoaManager();

function  queryConnectCB (
  userData: string,
  values: unknown[][],
  type: WinccoaConnectUpdateType,
  error?: WinccoaError,
) {
  if (error) {
    console.error(error);
    return;
  }

  if (type == WinccoaConnectUpdateType.Answer)
    console.warn('--- Initial update --- ' + userData);

  // ignore line with index 0 (it's a header) and start with index 1
  for (let i = 1; i < values.length; i++) {
    console.info(`DPE = '%s', value = %s`, ...values[i]);
  }
}

function connectUserData(userData: string) {
  let id = -1;
  try {
    id = winccoa.dpQueryConnectSingle(
      // use arrow function to add userData for callback
      (values, type, error?) => queryConnectCB(userData, values, type, error),
      true,
      "SELECT '_original.._value' FROM 'ExampleDP_Arg*'",
    );
  } catch (exc) {
    console.error(exc);
  }
}
```

## Parameters

• **values**: `unknown`[][]

Updated value(s) in a table-like structure:
[0][0] (empty)    | [0][1] column header   |         ...
----------------- | ---------------------- | ----------------------
[1][0] line name  | [1][0] content of line |         ...
[2][0] line name  | [2][1] content of line |         ...
...               | ...                    |         ...

e.g. this is the output for the query `"SELECT '_original.._value' FROM 'ExampleDP_Arg*'"` converted
to JSON:
```
[
  ["",":_original.._value"],
  ["System1:ExampleDP_Arg1.",2.43],
  ["System1:ExampleDP_Arg2.",5.76]
]
```

• **type**: [`WinccoaConnectUpdateType`](../enumerations/WinccoaConnectUpdateType.md)

Type of the update.

• **error?**: [`WinccoaError`](../classes/WinccoaError.md)

In case of an error, the other parameters are undefined and this parameter will
             contain error information.
> When the query passed to [WinccoaManager.dpQueryConnectAll](../classes/WinccoaManager.md#dpqueryconnectall) or
> [WinccoaManager.dpQueryConnectSingle](../classes/WinccoaManager.md#dpqueryconnectsingle) is invalid, no exception will be thrown by
> these methods, but the first (and only) callback will contain a [WinccoaError](../classes/WinccoaError.md) in this parameter.

## Returns

`void` \| `Promise`\<`void`\>

## Source

winccoa-manager/lib/binding.ts:436
