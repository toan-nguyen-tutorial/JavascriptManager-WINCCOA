[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaManager

# Class: WinccoaManager

Main class of the TypeScript/JavaScript API to the __WinCC OA JavaScript Manager for Node.js&#174;__.

> **IMPORTANT**
>
> All methods described in this documentation must be __called from code inside a
> method or function__ to prevent unexpected or undefined behavior.

To use the API, an instance of this class needs to be created, e. g.:

## Example

```ts
import { WinccoaManager } from 'winccoa-manager';
const winccoa = new WinccoaManager();
```

## Constructors

<a id="constructors" name="constructors"></a>

### new WinccoaManager()

> **new WinccoaManager**(): [`WinccoaManager`](WinccoaManager.md)

Constructor - creates new instance of an API object.

#### Returns

[`WinccoaManager`](WinccoaManager.md)

#### Example

```ts
import { WinccoaManager } from 'winccoa-manager';
const winccoa = new WinccoaManager();
```

#### Source

winccoa-manager/lib/binding.ts:508

## Properties

<a id="api" name="api"></a>

### api

> `private` **api**: `WinccoaManagerApi`

#### Source

winccoa-manager/lib/binding.ts:497

***

<a id="winccoamanagerconnection" name="winccoamanagerconnection"></a>

### winccoaManagerConnection

> `private` **winccoaManagerConnection**: `ConnectionBinding`

#### Source

winccoa-manager/lib/binding.ts:498

## Methods

<a id="alertset" name="alertset"></a>

### alertSet()

> **alertSet**(`alerts`, `values`): `boolean`

Allows to set data point alert attributes.

#### Parameters

• **alerts**: [`WinccoaAlertTime`](WinccoaAlertTime.md) \| [`WinccoaAlertTime`](WinccoaAlertTime.md)[]

Alert(s) of type [WinccoaAlertTime](WinccoaAlertTime.md) to be set.

• **values**: `unknown`

Attribute value(s) to be set. Must have the same size as __alerts__. If __alerts__ is a
              single string and not an array, this parameter must also be a single value and not an array.

#### Returns

`boolean`

Boolean `true` in case of a success, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.

#### Note

The attributes and their constants which can be set with this method are described in the chapter
[_alert_hdl](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Notes/dpconfig_alert_hdl.html)

#### Throws

[WinccoaError](WinccoaError.md) when DPE does not exist, mismatch number of DPs and values,
invalid argument type, etc.

#### See

- [alertSetWait](WinccoaManager.md#alertsetwait)
- [alertSetTimed](WinccoaManager.md#alertsettimed)
- [alertSetTimedWait](WinccoaManager.md#alertsettimedwait)
- [WinccoaAlertTime](WinccoaAlertTime.md)
- [_alert_hdl](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Notes/dpconfig_alert_hdl.html)

#### Example

```ts
import { WinccoaManager, WinccoaAlertTime } from 'winccoa-manager';
const winccoa = new WinccoaManager();

async function alertSetTest() {
  const dpeWithAlert = 'ExampleDP_AlertHdl1.';  // assuming alert is triggered
  const result = await winccoa.dpQuery(
    "SELECT ALERT '_alert_hdl.._act_state', '_alert_hdl.._value' FROM '" +
    dpeWithAlert +
    "'",
  );

  const ts = result[result.length - 1][1] as WinccoaAlertTime;
  const alertTime = new WinccoaAlertTime(ts.date, ts.count, ts.dpe + '._comment');
  let isSuccess = false;
  try {
    isSuccess = winccoa.alertSet(alertTime, 'Alert comment text from winccoa node manager.');
  } catch (exc) {
    console.error(exc);
  }

  console.info("AlertSet is called successfully - " + isSuccess);
}
```

#### Source

winccoa-manager/lib/binding.ts:1064

***

<a id="alertsettimed" name="alertsettimed"></a>

### alertSetTimed()

> **alertSetTimed**(`time`, `alerts`, `values`): `boolean`

Allows to set data point alert attributes with a given timestamp.

#### Parameters

• **time**: `Date`

Source time for the attribute change.

• **alerts**: [`WinccoaAlertTime`](WinccoaAlertTime.md) \| [`WinccoaAlertTime`](WinccoaAlertTime.md)[]

Alert(s) of type [WinccoaAlertTime](WinccoaAlertTime.md) to be set.

• **values**: `unknown`

Attribute value to be set. Must have the same size as __alerts__. If __alerts__ is a
              single string and not an array, this parameter must also be a single value and not an array.

#### Returns

`boolean`

Boolean `true` in case of a success, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.

#### Note

The attributes and their constants which can be set with this method are described in the chapter
[_alert_hdl](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Notes/dpconfig_alert_hdl.html)

#### Throws

[WinccoaError](WinccoaError.md) when DPE does not exist, mismatch number of DPs and values,
invalid argument type, etc.

#### See

- [alertSet](WinccoaManager.md#alertset)
- [alertSetWait](WinccoaManager.md#alertsetwait)
- [alertSetTimedWait](WinccoaManager.md#alertsettimedwait)
- [WinccoaAlertTime](WinccoaAlertTime.md)
- [_alert_hdl](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Notes/dpconfig_alert_hdl.html)

#### Example

```ts
import { WinccoaManager, WinccoaAlertTime } from 'winccoa-manager';
const winccoa = new WinccoaManager();

async function alertSetTimedTest() {
  const dpeWithAlert = 'ExampleDP_AlertHdl1.';  // assuming alert is triggered
  const result = await winccoa.dpQuery(
    "SELECT ALERT '_alert_hdl.._act_state', '_alert_hdl.._value' FROM '" +
    dpeWithAlert +
    "'",
  );

  const timeStamp = new Date('2024-03-19T04:05:06.789Z');
  const ts = result[result.length - 1][1] as WinccoaAlertTime;
  const alertTime = new WinccoaAlertTime(ts.date, ts.count, ts.dpe + '._ack_state');
  let isSuccess = false;
  try {
    isSuccess = winccoa.alertSetTimed(timeStamp, alertTime, 1);
  } catch (exc) {
    console.error(exc);
  }

  console.info("AlertSet is called successfully - " + isSuccess);
}
```

#### Source

winccoa-manager/lib/binding.ts:1174

***

<a id="alertsettimedwait" name="alertsettimedwait"></a>

### alertSetTimedWait()

> **alertSetTimedWait**(`time`, `alerts`, `values`): `Promise`\<`unknown`\>

Allows to set data point alert attributes with a given timestamp.

#### Parameters

• **time**: `Date`

Source time for the attribute change.

• **alerts**: [`WinccoaAlertTime`](WinccoaAlertTime.md) \| [`WinccoaAlertTime`](WinccoaAlertTime.md)[]

Alert(s) of type [WinccoaAlertTime](WinccoaAlertTime.md) to be set.

• **values**: `unknown`

Attribute value to be set. Must have the same size as __alerts__. If __alerts__ is a
              single string and not an array, this parameter must also be a single value and not an array.

#### Returns

`Promise`\<`unknown`\>

Promise that resolves to `true` if successful. If not successful,
         a [WinccoaError](WinccoaError.md) wil be thrown instead.

Boolean `true` in case of a success, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.

#### Throws

[WinccoaError](WinccoaError.md) when DPE does not exist, mismatch number of DPs and values,
invalid argument type, etc.

#### See

- [alertSet](WinccoaManager.md#alertset)
- [alertSetWait](WinccoaManager.md#alertsetwait)
- [alertSetTimed](WinccoaManager.md#alertsettimed)
- [WinccoaAlertTime](WinccoaAlertTime.md)
- [_alert_hdl](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Notes/dpconfig_alert_hdl.html)

#### Example

```ts
import { WinccoaManager, WinccoaAlertTime } from 'winccoa-manager';
const winccoa = new WinccoaManager();

async function alertSetTimedWaitTest() {
  const dpeWithAlert = 'ExampleDP_AlertHdl1.'; // assuming alert is triggered
  const result = await winccoa.dpQuery(
    `SELECT ALERT '_alert_hdl.._act_state', '_alert_hdl.._value' FROM '${dpeWithAlert}'`,
  );

  const timeStamp = new Date('2024-03-19T04:05:06.789Z');
  const ts = result[result.length - 1][1] as WinccoaAlertTime;
  const alertTime = new WinccoaAlertTime(
    ts.date,
    ts.count,
    ts.dpe + '._ack_state',
  );

  try {
    await winccoa.alertSetTimedWait(timeStamp, alertTime, 1);
    console.info(`Alert is acknowledged at ${timeStamp}`);
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/binding.ts:1228

***

<a id="alertsetwait" name="alertsetwait"></a>

### alertSetWait()

> **alertSetWait**(`alerts`, `values`): `Promise`\<`unknown`\>

Allows to set data point alert attributes.

#### Parameters

• **alerts**: [`WinccoaAlertTime`](WinccoaAlertTime.md) \| [`WinccoaAlertTime`](WinccoaAlertTime.md)[]

Alert(s) of type [WinccoaAlertTime](WinccoaAlertTime.md) to be set.

• **values**: `unknown`

Attribute value(s) to be set. Must have the same size as __alerts__. If __alerts__ is a
              single string and not an array, this parameter must also be a single value and not an array.

#### Returns

`Promise`\<`unknown`\>

Promise that resolves to `true` if successful. If not successful,
         a [WinccoaError](WinccoaError.md) wil be thrown instead.

Boolean `true` in case of a success, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.

#### Throws

[WinccoaError](WinccoaError.md) when DPE does not exist, mismatch number of DPs and values,
invalid argument type, etc.

#### See

- [alertSet](WinccoaManager.md#alertset)
- [alertSetTimed](WinccoaManager.md#alertsettimed)
- [alertSetTimedWait](WinccoaManager.md#alertsettimedwait)
- [WinccoaAlertTime](WinccoaAlertTime.md)
- [_alert_hdl](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Notes/dpconfig_alert_hdl.html)

#### Example

```ts
import { WinccoaManager, WinccoaAlertTime } from 'winccoa-manager';
const winccoa = new WinccoaManager();

async function alertSetWaitTest() {
  const dpeWithAlert = 'ExampleDP_AlertHdl1.'; // assuming alert is triggered
  const result = await winccoa.dpQuery(
    `SELECT ALERT '_alert_hdl.._act_state', '_alert_hdl.._value' FROM '${dpeWithAlert}'`,
  );

  const ts = result[result.length - 1][1] as WinccoaAlertTime;
  const alertTime = new WinccoaAlertTime(
    ts.date,
    ts.count,
    ts.dpe + '._comment',
  );

  try {
    await winccoa.alertSetWait(
      alertTime,
      'Alert comment text from winccoa node manager.',
    );
    console.info(`Comment for alert of '${dpeWithAlert}' is successfully set`);
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/binding.ts:1118

***

<a id="dpconnect" name="dpconnect"></a>

### dpConnect()

> **dpConnect**(`callback`, `dpeNames`, `answer`): `number`

Creates a connection for being notified of datapoint element updates.

#### Parameters

• **callback**: [`WinccoaDpConnectCallback`](../type-aliases/WinccoaDpConnectCallback.md)

Function that is called whenever a connected value changes.

• **dpeNames**: `string` \| `string`[]

DPE name(s) to connect to.
> - Each update will contain updates for all elements in __dpeNames__, not only
  the changed values.
  - Each update will contain an array of values, also if only a single datapoint element
    name is given.

• **answer**: `boolean`= `true`

if `true`, __callback__ is called with the initial values right away, if `false`,
              callback is only called after an actual value change.

#### Returns

`number`

ID of the new connection (>= 0). This can be used to disconnect from
         updates if required with [dpDisconnect](WinccoaManager.md#dpdisconnect). Otherwise the connection will be closed
         when the manager exits.

#### Throws

[WinccoaError](WinccoaError.md) when invalid parameter types, unknown datapoint element names etc.

#### Remark

For an example describing how to pass user data to a callback, see the second example
        for [WinccoaDpQueryConnectCallback](../type-aliases/WinccoaDpQueryConnectCallback.md).

#### See

- [dpDisconnect](WinccoaManager.md#dpdisconnect)
- [WinccoaDpConnectCallback](../type-aliases/WinccoaDpConnectCallback.md)
- [WinccoaConnectUpdateType](../enumerations/WinccoaConnectUpdateType.md)

#### Example

``` ts
import {
  WinccoaManager,
  WinccoaConnectUpdateType,
  WinccoaError
} from 'winccoa-manager';
const winccoa = new WinccoaManager();

function connectCB(
  names: string[],
  values: unknown[],
  type: WinccoaConnectUpdateType,
  error?: WinccoaError
) {
  if (error) {
    console.log(error);
    return;
  }

  if (type == WinccoaConnectUpdateType.Answer)
    console.warn('--- Initial update ---');

  for (let i = 0; i < names.length; i++)
    console.info(`[${i}] '${names[i]}' : ${values[i]}`);
}

function connect() {
  let id = -1;
  try {
    id = winccoa.dpConnect(
      connectCB,
      ['ExampleDP_Arg1.', 'ExampleDP_Arg2.'],
      true
    );
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/binding.ts:1303

***

<a id="dpcopy" name="dpcopy"></a>

### dpCopy()

> **dpCopy**(`source`, `destination`, `driver`?): `Promise`\<`boolean`\>

Copies a data point including its configuration.

#### Parameters

• **source**: `string`

Name of the datapoint to copy.

• **destination**: `string`

Name of the new copied datapoint. Must not exist yet.

• **driver?**: `number`

Optional driver number (default 1).

#### Returns

`Promise`\<`boolean`\>

Promise - will be resolved to `true` if successful or rejected with an error.
         In case of an error, `error.details` will contain the same error code
         that CTRL function dpCopy() would return (see there).

#### Throws

[WinccoaError](WinccoaError.md) when given source datapoint does not exist, when datapoint is copied into itself, invalid argument given, etc.

#### See

- [CTRL function `dpCopy()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpCopy.html)

#### Example

```ts
async function dpCopyTest() {
  let isSuccess = false;
  try {
    isSuccess = await winccoa.dpCopy('ExampleDP_Arg1', 'ExampleDP_Arg3');
  } catch (exc) {
    console.error(exc);
  }

  console.info("DP ExampleDP_Arg1 is copied to ExampleDP_Arg3 successfully - " + isSuccess);
}
```

#### Source

winccoa-manager/lib/binding.ts:1470

***

<a id="dpcreate" name="dpcreate"></a>

### dpCreate()

> **dpCreate**(`dpeName`, `dpType`, `systemId`?, `dpId`?): `Promise`\<`boolean`\>

Creates a data point.

#### Parameters

• **dpeName**: `string`

Name of the data point to be created.

• **dpType**: `string`

Type of data point to be created.

• **systemId?**: `number`

To create a data point on a remote system in a distributed system,
                this parameter must contain the system number.

• **dpId?**: `number`

The ID of the data point. If a data point with the given ID already
            exists, a random ID is chosen.

#### Returns

`Promise`\<`boolean`\>

Promise - will be resolved to `true` if successful or rejected with an error.

#### Throws

[WinccoaError](WinccoaError.md) in case of:
- invalid argument type is given,
- invalid __dpeName__, __dpType__ or non-existing __systemId__ is given,
- data point with the given __dpeName__ is already exist.

#### See

- [dpDelete](WinccoaManager.md#dpdelete)
- [CTRL function `dpCreate()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpCreate.html)

#### Example

```ts
let dpCreated = false;
try {
  dpCreated = await winccoa.dpCreate('newFloatDpe', 'ExampleDP_Float');
} catch (exc) {
  console.error(exc);
}

console.info("DP newFloatDpe is created - " + dpCreated);
```

#### Source

winccoa-manager/lib/binding.ts:822

***

<a id="dpdelete" name="dpdelete"></a>

### dpDelete()

> **dpDelete**(`dpName`): `Promise`\<`boolean`\>

Deletes a data point.

#### Parameters

• **dpName**: `string`

Name of the data point to be deleted.
           In case of a distributed system the name of the data point
           to be deleted must contain the system name.

#### Returns

`Promise`\<`boolean`\>

Promise - will be resolved to `true` if successful or rejected with an error.

#### Throws

[WinccoaError](WinccoaError.md) when datapoint with the given name does not exist or current user has no privileges to delete a DP.

#### See

- [dpCreate](WinccoaManager.md#dpcreate)
- [CTRL function `dpDelete()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpDelete.html)

#### Example

```ts
let isSuccess = false;
try {
  isSuccess = await winccoa.dpCreate('newDpe', 'ExampleDP_Float');
} catch (exc) {
  console.error(exc);
}

if (isSuccess)
{
  try {
    isSuccess = await winccoa.dpDelete('newDpe');
  } catch (exc) {
    console.error(exc);
  }
}

console.info("DP newDpe was deleted successfully - " + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:1440

***

<a id="dpdisconnect" name="dpdisconnect"></a>

### dpDisconnect()

> **dpDisconnect**(`id`): `number`

Disconnect from datapoint element update connections established with [dpConnect](WinccoaManager.md#dpconnect).

#### Parameters

• **id**: `number`

ID of the connection to close as returned by [dpConnect](WinccoaManager.md#dpconnect).

#### Returns

`number`

ID of the connection that has been closed (>= 0).

#### Throws

[WinccoaError](WinccoaError.md) when __id__ is not found or invalid.

#### See

- [dpConnect](WinccoaManager.md#dpconnect)

#### Example

```ts
function connect() {
  let id = -1;
  try {
    id = winccoa.dpConnect(
      connectCB,
      ['ExampleDP_Arg1.', 'ExampleDP_Arg2.'],
      true
    );
  } catch (exc) {
    console.error(exc);
  }
}

function disconnect() {
  try {
    winccoa.dpDisconnect(id);
  } catch (exc) {
   console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/binding.ts:1348

***

<a id="dpelementtype" name="dpelementtype"></a>

### dpElementType()

> **dpElementType**(`dpeName`): [`WinccoaElementType`](../enumerations/WinccoaElementType.md)

Returns the data typeof a data point element.

#### Parameters

• **dpeName**: `string`

Name of the data point element

#### Returns

[`WinccoaElementType`](../enumerations/WinccoaElementType.md)

Type of a data point element

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type.

#### See

- [WinccoaElementType](../enumerations/WinccoaElementType.md)
- [CTRL function `dpElementType()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpElementType.html)

#### Example

```ts
import { WinccoaManager, WinccoaElementType } from 'winccoa-manager';
const winccoa = new WinccoaManager();

async function dpElementTypeTest()
  try {
    let dpType = await winccoa.dpElementType('ExampleDP_Arg1.');
    console.info('The type of ExampleDP_Arg1 is float - ' + (dpType == WinccoaElementType.Float));
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/binding.ts:2018

***

<a id="dpexists" name="dpexists"></a>

### dpExists()

> **dpExists**(`dpeName`): `boolean`

Checks the existence of a valid data point identifier.

#### Parameters

• **dpeName**: `string`

A data point identifier: a sys, a DPT, a DP, a DPE, a config, a detail or an attr.

#### Returns

`boolean`

true if at least one part of a data point identifier can be resolved correctly, otherwise false.

#### Throws

[WinccoaError](WinccoaError.md) when invalid argument type is given.

#### See

- [CTRL function `dpExists()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpExists.html)

#### Example

```ts
let isDpExists = false;
try {
  isDpExists = winccoa.dpExists('ExampleDP_Arg1.');
} catch (exc) {
  console.error(exc);
}
console.info("Is ExampleDP_Arg1 exists - " + isDpExists);
```

#### Source

winccoa-manager/lib/binding.ts:671

***

<a id="dpget" name="dpget"></a>

### dpGet()

> **dpGet**(`dpeNames`): `Promise`\<`unknown`\>

Get the current values of one or more datapoint elements.

#### Parameters

• **dpeNames**: `string` \| `string`[]

Datapoint element name(s) of the values to get.

#### Returns

`Promise`\<`unknown`\>

Promise that resolves to the current value(s) of the DPE(s). The received values
         must be cast to their expected types before they can be used.

#### Async

#### Throws

[WinccoaError](WinccoaError.md) when DPE does not exist or current user has no read access to it.

#### See

[CTRL function `dpGet()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpGet.html)

#### Example

```ts
const dpes = ['ExampleDP_Arg1.', 'ExampleDP_DDE.b1'];
try {
  const values = (await winccoa.dpGet(dpes)) as [number, boolean];
  for (let i = 0; i < dpes.length; i++) {
    console.info(`${dpes[i]}: ${values[i]}`);
  }
} catch (exc) {
  console.error(exc);
}
```

#### Source

winccoa-manager/lib/binding.ts:1013

***

<a id="dpgetalias" name="dpgetalias"></a>

### dpGetAlias()

> **dpGetAlias**(`dpeName`): `string`

Returns the alias for the specified data point.

#### Parameters

• **dpeName**: `string`

Data point element

#### Returns

`string`

the appropriate alias in the language. Note that the alias can be only unilingual.

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type.

#### See

- [dpSetAlias](WinccoaManager.md#dpsetalias)
- [CTRL function `dpGetAlias()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpGetAlias.html)

#### Example

```ts
try {
  let alias = winccoa.dpGetAlias('ExampleDP_Rpt1.');
  console.info('DP alias: ' + alias);
} catch (exc) {
  console.error(exc);
}
```

#### Source

winccoa-manager/lib/binding.ts:1990

***

<a id="dpgetdescription" name="dpgetdescription"></a>

### dpGetDescription()

> **dpGetDescription**(`dpeName`, `mode`?): `unknown`

Returns the comment (description) for the data point.

#### Parameters

• **dpeName**: `string`

Data point element or data point

• **mode?**: `number`

Mode of functionality.
For more details on all modes description see
[CTRL function `dpGetDescription()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpGetDescription.html).

#### Returns

`unknown`

Description in all available languages as langText or empty strings in all
         languages.
> The returned data type can be defined with [setOptions](WinccoaManager.md#setoptions).

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type.

#### See

- [dpSetDescription](WinccoaManager.md#dpsetdescription)
- [CTRL function `dpGetDescription()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpGetDescription.html)

#### Example

```ts
let description;
try {
  description = winccoa.dpGetDescription('ExampleDP_Rpt1.');
} catch (exc) {
  console.error(exc);
  description = null;
}

if (description)
  console.info('DP description: ' + description);
```

#### Source

winccoa-manager/lib/binding.ts:1937

***

<a id="dpgetformat" name="dpgetformat"></a>

### dpGetFormat()

> **dpGetFormat**(`dpeName`): `unknown`

This function returns the numerical format(s) of a data point.

#### Parameters

• **dpeName**: `string`

Data point element

#### Returns

`unknown`

Returns a string that contains the format (for example, '%6.2f') in one or several
         languages or an empty string if an error occured.
> The returned data type can be defined with [setOptions](WinccoaManager.md#setoptions).

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type.

#### See

- [dpSetFormat](WinccoaManager.md#dpsetformat)
- [CTRL function `dpGetFormat()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpGetFormat.html)

#### Example

```ts
let formats;
try {
  formats = winccoa.dpGetFormat('ExampleDP_Rpt1.');
} catch (exc) {
  console.error(exc);
  formats = null;
}

if (formats)
  console.info('DP formats: ' + formats);
```

#### Source

winccoa-manager/lib/binding.ts:1874

***

<a id="dpgetunit" name="dpgetunit"></a>

### dpGetUnit()

> **dpGetUnit**(`dpeName`): `unknown`

This function returns the unit(s) of a data point.

#### Parameters

• **dpeName**: `string`

Data point element

#### Returns

`unknown`

Returns the unit as langText in one or several languages. In the event of an
         error, an empty string is returned.
> The returned data type can be defined with [setOptions](WinccoaManager.md#setoptions).

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type.

#### See

- [dpSetUnit](WinccoaManager.md#dpsetunit)
- [setOptions](WinccoaManager.md#setoptions)
- [CTRL function `dpGetUnit()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpGetUnit.html)

#### Example

```ts
try {
  let units = winccoa.dpGetUnit('ExampleDP_Rpt1.');
  console.info('DP units: ' + units);
} catch (exc) {
  console.error(exc);
}
```

#### Source

winccoa-manager/lib/binding.ts:1815

***

<a id="dpnames" name="dpnames"></a>

### dpNames()

> **dpNames**(`dpPattern`, `dpType`, `ignoreCase`): `string`[]

Returns all the data point names or the data point element names that match a pattern in alphabetical order.

#### Parameters

• **dpPattern**: `string`= `''`

Serach pattern. When an empty pattern is given (=default), then returns all datapoints.
<br>Wildcards are used to filter data point name.
The charcters `*` and `?` are used for the purpose,
where the asterisk (`*`) replaces any number of characters and the question mark `?` stands for just one character.
Only data points that have the same number of levels as specified are found.
Levels are separated by a period. `dpNames(**)` is equivalent to `dpNames(*.*)`.
<br>Furthermore:
- `:*` returns all configs, `:config.*` returns all details, `:config.detail.*` returns all attributes
- `dp.el:*` returns only the configs according to the DPE. , for example, no `_original` for a node.

<br>Wildcards can be used in arrays (square brackets , e.g.: `[0,3,5-7]` - numbers 0,3,5,6,7) or outside arrays in option lists (in curly brackets `{}`).
<br>Example of wildcards in lists of options:
```
winccoa.dpNames('{*.Ala.*,*.Ala*}', dpType);
winccoa.dpNames('*{.Ala.,.Ala}*', dpType);
winccoa.dpNames('*.A{la.,la}*', dpType);
winccoa.dpNames('*.Al{a.,a}*', dpType);
winccoa.dpNames('*.Ala{.,}*', dpType);
winccoa.dpNames('*.Ala{.}*', dpType);
winccoa.dpNames('*.Ala.*', dpType);
winccoa.dpNames('*.Ala*', dpType);
```

• **dpType**: `string`= `''`

Data point type. Allows to restrict the returned data points to a specific data point type.
When using the parameter only data points that match the pattern and the selected data point type will be returned.

• **ignoreCase**: `boolean`= `false`

Defines if the search should ignore the casing of the search pattern (=true) or not (=false, default)

#### Returns

`string`[]

List with data points or data point element names.

#### Throws

[WinccoaError](WinccoaError.md) when invalid argument type is given.

#### See

- [CTRL function `dpNames()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpNames.html)

#### Example

```ts
let foundDpNames: string[] = [];
try {
  foundDpNames = winccoa.dpNames('ExampleDP*', 'ExampleDP_Float');
} catch (exc) {
  console.error(exc);
}

for (let i = 0; i < foundDpNames.length; i++) {
  console.info("DPE name: " + foundDpNames.at(i));
}
```

#### Source

winccoa-manager/lib/binding.ts:719

***

<a id="dpquery" name="dpquery"></a>

### dpQuery()

> **dpQuery**(`query`): `Promise`\<`unknown`[][]\>

Retrieves attribute values with the help of SQL statements.

#### Parameters

• **query**: `string`

SQL statement.

#### Returns

`Promise`\<`unknown`[][]\>

Promise - will be resolved to `true` if successful or rejected with an error.

#### Note

The query result has a table-like structure:
[0][0] (empty)    | [0][1] column header   |         ...
----------------- | ---------------------- | ----------------------
[1][0] line name  | [1][0] content of line |         ...
[2][0] line name  | [2][1] content of line |         ...
...               | ...                    |         ...

e.g. this is the output for the query `"SELECT '_original.._value' FROM 'ExampleDP_Arg*'"` converted
to JSON:
```
[
  ["",":_original.._value"],
  ["System1:ExampleDP_Arg1.",2.43],
  ["System1:ExampleDP_Arg2.",5.76]
]
```

#### Throws

[WinccoaError](WinccoaError.md) when invalid parameter or query string is given.

#### See

- [dpQueryConnectSingle](WinccoaManager.md#dpqueryconnectsingle)
- [dpQueryConnectAll](WinccoaManager.md#dpqueryconnectall)
- [CTRL function `dpQuery()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpQuery.html)

#### Example

```ts
let result;
try {
  result = await winccoa.dpQuery(
    `SELECT '_original.._stime', '_original.._value' FROM 'ExampleDP_Arg*'`,
  );
} catch (exc) {
  console.error(exc);
  result = null;
}
if (result) {
  const queryTable: string[][] = result as string[][];
  for (let i = 0; i < queryTable.length; i++) {
    console.info(
      `query line - name: '%s' - timestamp = %s - value = %s`,
      ...queryTable[i],
    );
  }
}
 ```

#### Source

winccoa-manager/lib/binding.ts:1540

***

<a id="dpqueryconnectall" name="dpqueryconnectall"></a>

### dpQueryConnectAll()

> **dpQueryConnectAll**(`callback`, `answer`, `query`): `number`

Calls __callback__ whenever one or more DPEs which meet the query condition change.
> It is recommended to use [dpQueryConnectSingle](WinccoaManager.md#dpqueryconnectsingle) if possible from the
> performance point of view.

#### Parameters

• **callback**: [`WinccoaDpQueryConnectCallback`](../type-aliases/WinccoaDpQueryConnectCallback.md)

Function that is called whenever a subscribed DPE value changes.
                The update message will contain all subscribed DPEs.

• **answer**: `boolean`

if true, callback is called with the initial DPE values right away, if false,
              callback is only called for an actual value change.

• **query**: `string`

query as an SQL statement.

#### Returns

`number`

ID of the new connection (>= 0). This can be used to disconnect from
         updates if required with [dpQueryDisconnect](WinccoaManager.md#dpquerydisconnect). Otherwise the connection will be closed
         when the manager exits.

#### Throws

[WinccoaError](WinccoaError.md) when invalid parameter types, empty or invalid query, etc.
> When the query passed to this method is invalid, no exception is thrown,
> but the first (and only) callback will contain a [WinccoaError](WinccoaError.md) instead.

#### Remark

For an example describing how to pass user data to a callback, see the second example
        for [WinccoaDpQueryConnectCallback](../type-aliases/WinccoaDpQueryConnectCallback.md).

#### See

- [dpQuery](WinccoaManager.md#dpquery)
- [dpQueryConnectSingle](WinccoaManager.md#dpqueryconnectsingle)
- [dpQueryDisconnect](WinccoaManager.md#dpquerydisconnect)
- [WinccoaConnectUpdateType](../enumerations/WinccoaConnectUpdateType.md)
- [CTRL function `dpQueryConnectAll()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpQueryConnectAll.html)

#### Example

```ts
import {
  WinccoaManager,
  WinccoaConnectUpdateType,
  WinccoaError
} from 'winccoa-manager';
const winccoa = new WinccoaManager();

function  queryConnectCB (
  values: unknown[][],
  type: WinccoaConnectUpdateType,
  error?: WinccoaError
) {
  if (error) {
    console.log(error);
    return;
  }

  if (type == WinccoaConnectUpdateType.Answer)
    console.warn('--- Initial update ---');

  for (let i = 0; i < values.length; i++) {
    console.info(`DPE = '%s', value = %s`, ...values[i]);
  }
}

function connect() {
  let id = -1;
  try {
    id = winccoa.dpQueryConnectAll(
      queryConnectCB,
      true,
      `SELECT '_online.._value' FROM '*' WHERE _DPT="ExampleDP_Float"`
    );
  } catch (exc) {
    console.error(exc);
  }
}
 ```

#### Source

winccoa-manager/lib/binding.ts:1680

***

<a id="dpqueryconnectsingle" name="dpqueryconnectsingle"></a>

### dpQueryConnectSingle()

> **dpQueryConnectSingle**(`callback`, `answer`, `query`): `number`

Calls __callback__ whenever one or more DPEs which meet the query condition are changed.

#### Parameters

• **callback**: [`WinccoaDpQueryConnectCallback`](../type-aliases/WinccoaDpQueryConnectCallback.md)

Function that is called whenever a subscribed DPE value changes.
                The update message will contain only changed DPEs.

• **answer**: `boolean`

if true, callback is called with the initial DPE values right away, if false,
              callback is only called for an actual value change.

• **query**: `string`

query as an SQL statement.

#### Returns

`number`

ID of the new connection (>= 0). This can be used to disconnect from
         updates if required with [dpQueryDisconnect](WinccoaManager.md#dpquerydisconnect). Otherwise the connection will be closed
         when the manager exits.

#### Throws

[WinccoaError](WinccoaError.md) when invalid parameter types, empty query, etc.
> When the query passed to this method is invalid, no exception is thrown,
> but the first (and only) callback will contain a [WinccoaError](WinccoaError.md) instead.

#### Remark

For an example describing how to pass user data to a callback, see the second example
        for [WinccoaDpQueryConnectCallback](../type-aliases/WinccoaDpQueryConnectCallback.md).

#### See

- [dpQuery](WinccoaManager.md#dpquery)
- [dpQueryConnectAll](WinccoaManager.md#dpqueryconnectall)
- [dpQueryDisconnect](WinccoaManager.md#dpquerydisconnect)
- [WinccoaConnectUpdateType](../enumerations/WinccoaConnectUpdateType.md)
- [CTRL function `dpQueryConnectSingle()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpQueryConnectSingle.html)

#### Example

```ts
import {
  WinccoaManager,
  WinccoaConnectUpdateType,
  WinccoaError
} from 'winccoa-manager';
const winccoa = new WinccoaManager();

function  queryConnectCB (
  values: unknown[][],
  type: WinccoaConnectUpdateType,
  error?: WinccoaError
) {
  if (error) {
    console.log(error);
    return;
  }

  if (type == WinccoaConnectUpdateType.Answer)
    console.warn('--- Initial update ---');

  for (let i = 0; i < values.length; i++) {
    console.info(`DPE = '%s', value = %s`, ...values[i]);
  }
}

function connect() {
  let id = -1;
  try {
    id = winccoa.dpQueryConnectSingle(
      queryConnectCB,
      true,
      `SELECT '_online.._value' FROM '*' WHERE _DPT="ExampleDP_Float"`
    );
  } catch (exc) {
    console.error(exc);
  }
}
 ```

#### Source

winccoa-manager/lib/binding.ts:1607

***

<a id="dpquerydisconnect" name="dpquerydisconnect"></a>

### dpQueryDisconnect()

> **dpQueryDisconnect**(`id`): `number`

Disconnect from [dpQueryConnectSingle](WinccoaManager.md#dpqueryconnectsingle) (or [dpQueryConnectAll](WinccoaManager.md#dpqueryconnectall)) .

#### Parameters

• **id**: `number`

ID of the connection to close as returned by [dpQueryConnectAll](WinccoaManager.md#dpqueryconnectall) or [dpQueryConnectSingle](WinccoaManager.md#dpqueryconnectsingle).

#### Returns

`number`

ID of the closed connection (>= 0).

#### Throws

[WinccoaError](WinccoaError.md) when __id__ is not found or invalid.

#### See

- [dpQueryConnectAll](WinccoaManager.md#dpqueryconnectall)
 - [dpQueryConnectSingle](WinccoaManager.md#dpqueryconnectsingle)

#### Example

```ts
import {
  WinccoaManager,
  WinccoaConnectUpdateType,
  WinccoaError
} from 'winccoa-manager';
const winccoa = new WinccoaManager();

function connect() {
let id = -1;
  try {
    id = winccoa.dpQueryConnectSingle(
      function (
        values: unknown[][],
        type: WinccoaConnectUpdateType,
        error?: WinccoaError
      ) {
        if (error) {
          console.log(error);
          return;
        }

        console.info(values)
      },
      true,
      "SELECT '_online.._value' FROM '*' WHERE _DPT= \"ExampleDP_Float\""
      );
  } catch (exc) {
    console.error(exc);
  }
}

function disconnect() {
  try {
    winccoa.dpQueryDisconnect(id);
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/binding.ts:1740

***

<a id="dpset" name="dpset"></a>

### dpSet()

> **dpSet**(`dpeNames`, `values`): `boolean`

Set the value of one or more datapoint element(s).

#### Parameters

• **dpeNames**: `string` \| `string`[]

Datapoint element name(s) of the values to set.

• **values**: `unknown`

Values to set. Must have the same size as __dpeNames__. If __dpeNames__ is a
              single string and not an array, this parameter must also be a single value
              and not an array.

#### Returns

`boolean`

`true` if successful, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.
> Since this method does not wait for the actual value update
> in the database, __the update can still fail__ after this method returned `true`. Use
[dpSetWait](WinccoaManager.md#dpsetwait) to also get informed about these errors.

#### Throws

[WinccoaError](WinccoaError.md) when DPE names do not exist, values cannot be converted, array
        sizes mismatch etc.

#### See

- [dpSetWait](WinccoaManager.md#dpsetwait)
- [dpSetTimed](WinccoaManager.md#dpsettimed)
- [dpSetTimedWait](WinccoaManager.md#dpsettimedwait)
- [CTRL function `dpSet()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSet.html)

#### Example

```ts
const dpes = ['ExampleDP_Arg1.', 'ExampleDP_DDE.b1'];
const values = [123.456, false];
try {
  winccoa.dpSet(dpes, values); // Two arrays of size 2
  winccoa.dpSet('ExampleDP_Arg2.', 2); // single value
} catch (exc) {
  console.error(exc);
}
```

#### Source

winccoa-manager/lib/binding.ts:863

***

<a id="dpsetalias" name="dpsetalias"></a>

### dpSetAlias()

> **dpSetAlias**(`dpeName`, `alias`): `Promise`\<`unknown`\>

Sets the alias for the specified data point element.

#### Parameters

• **dpeName**: `string`

Data point element

• **alias**: `string`

Alias to be set. Note that the alias can be set only unilingual.

#### Returns

`Promise`\<`unknown`\>

Promise - will be resolved to true if successful or rejected with an error.

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type, etc.

#### See

- [dpGetAlias](WinccoaManager.md#dpgetalias)
- [CTRL function `dpSetAlias()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSetAlias.html)

#### Example

```ts
let isSuccess = false;
try {
  isSuccess = await winccoa.dpSetAlias('ExampleDP_Rpt1.', 'rpt1Alias');
} catch (exc) {
  console.error(exc);
}

console.info('DP alias is set successfully - ' + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:2044

***

<a id="dpsetdescription" name="dpsetdescription"></a>

### dpSetDescription()

> **dpSetDescription**(`dpeName`, `comment`): `Promise`\<`boolean`\>

Sets a comment (description) for the data point.

#### Parameters

• **dpeName**: `string`

Data point element to be commented on

• **comment**: `unknown`

Comment as langText

#### Returns

`Promise`\<`boolean`\>

Promise - will be resolved to `true` if successful or rejected with an error.

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type, etc.

#### See

- [dpGetDescription](WinccoaManager.md#dpgetdescription)
- [CTRL function `dpSetDescription()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSetDescription.html)

#### Example

```ts
let isSuccess = false;
try {
  isSuccess = await winccoa.dpSetDescription('ExampleDP_Rpt1.', {
     'de_AT.utf8': 'German description',
     'en_US.utf8': 'English description',
     'ru_RU.utf8': 'Russian description',
   });
} catch (exc) {
  console.error(exc);
}

console.info('DP description is set successfully - ' + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:1967

***

<a id="dpsetformat" name="dpsetformat"></a>

### dpSetFormat()

> **dpSetFormat**(`dpeName`, `format`): `Promise`\<`unknown`\>

Sets the numerical format(s) of a data point.

#### Parameters

• **dpeName**: `string`

Data point element

• **format**: `unknown`

A string that contains the format (for example, '%6.2f') in one or several
               languages.

#### Returns

`Promise`\<`unknown`\>

Promise - will be resolved to `true` if successful or rejected with an error.

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type, etc.

#### See

- [dpGetFormat](WinccoaManager.md#dpgetformat)
- [CTRL function `dpSetFormat()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSetFormat.html)

#### Example

```ts
let isSuccess = false;
try {
  isSuccess = await winccoa.dpSetFormat('ExampleDP_Rpt1.', {
     'de_AT.utf8': '%.4f',
     'en_US.utf8': '%.4f',
     'ru_RU.utf8': '%.2f',
   });
} catch (exc) {
  console.error(exc);
}

  console.info('DP formats are set successfully - ' + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:1905

***

<a id="dpsettimed" name="dpsettimed"></a>

### dpSetTimed()

> **dpSetTimed**(`time`, `dpeNames`, `values`): `boolean`

Set values of one or more datapoint element(s) with a given source time.

#### Parameters

• **time**: `Date`

Source time for the value change.

• **dpeNames**: `string` \| `string`[]

Datapoint element name(s) of the values to set.

• **values**: `unknown`

Values to set. Must have the same size as __dpeNames__. If __dpeNames__ is a
              single string and not an array, this parameter must also be a single value
              and not an array.

#### Returns

`boolean`

Boolean `true` in case of a success, otherwise `false`.
> Since this method does not wait for the actual value update
> in the database, __the update can still fail__ after this method returned `true`. Use
[dpSetTimedWait](WinccoaManager.md#dpsettimedwait) to also get informed about these errors.

#### Throws

[WinccoaError](WinccoaError.md) when DPE names do not exist, values cannot be converted, array
        sizes mismatch etc.

#### See

- [dpSet](WinccoaManager.md#dpset)
- [dpSetWait](WinccoaManager.md#dpsetwait)
- [dpSetTimedWait](WinccoaManager.md#dpsettimedwait)
- [CTRL function `dpSetTimed()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSetTimed.html)

#### Example

```ts
const timeStamp = new Date('2023-01-03T04:05:06.789Z');
let isSuccess = false;
try {
  isSuccess = winccoa.dpSetTimed(timeStamp, 'ExampleDP_Arg1.', 2);
} catch (exc) {
  console.error(exc);
}

console.info("dpSetTimed call is successed - " + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:938

***

<a id="dpsettimedwait" name="dpsettimedwait"></a>

### dpSetTimedWait()

> **dpSetTimedWait**(`time`, `dpeNames`, `values`): `Promise`\<`boolean`\>

Set values of one or more datapoint element(s) with a given source time.

#### Parameters

• **time**: `Date`

Source time for the value change.

• **dpeNames**: `string` \| `string`[]

Datapoint element name(s) of the values to set.

• **values**: `unknown`

Values to set. Must have the same size as __dpeNames__. If __dpeNames__ is a
              single string and not an array, this parameter must also be a single value
              and not an array.

#### Returns

`Promise`\<`boolean`\>

Promise that resolves to `true` if succesful. If not successful,
         a [WinccoaError](WinccoaError.md) wil be thrown instead.

Boolean `true` in case of a success, otherwise `false`.
> Since this method does not wait for the actual value update
> in the database, __the update can still fail__ after this method returned `true`. Use
[dpSetTimedWait](WinccoaManager.md#dpsettimedwait) to also get informed about these errors.

#### Throws

[WinccoaError](WinccoaError.md) when DPE names do not exist, values cannot be converted, array
        sizes mismatch, no write access etc.

#### See

- [dpSet](WinccoaManager.md#dpset)
- [dpSetTimed](WinccoaManager.md#dpsettimed)
- [dpSetWait](WinccoaManager.md#dpsetwait)
- [CTRL function `dpSetTimedWait()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSetTimedWait.html)

#### Example

```ts
const timeStamp = new Date('2023-01-03T04:05:06.789Z');
let isSuccess = false;
try {
  isSuccess = await winccoa.dpSetTimedWait(timeStamp, 'ExampleDP_Arg1.', 2);
} catch (exc) {
  console.error(exc);
}

console.info("Time and value are set for ExampleDP_Arg1 - " + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:977

***

<a id="dpsetunit" name="dpsetunit"></a>

### dpSetUnit()

> **dpSetUnit**(`dpeName`, `unit`): `Promise`\<`boolean`\>

Sets the unit(s) for a data point.

#### Parameters

• **dpeName**: `string`

Data point

• **unit**: `unknown`

Unit (for example, kg) in one or several languages as langText.

#### Returns

`Promise`\<`boolean`\>

Promise - will be resolved to `true` if successful or rejected with an error.

#### Throws

[WinccoaError](WinccoaError.md) when data point with the given __dpeName__ is not found or invalid argument type, etc.

#### See

- [dpGetUnit](WinccoaManager.md#dpgetunit)
- [CTRL function `dpSetUnit()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSetUnit.html)

#### Example

```ts
let isSuccess = false;
try {
  isSuccess = await winccoa.dpSetUnit('ExampleDP_Rpt1.', {
     'de_AT.utf8': 's',
     'en_US.utf8': 's',
     'ru_RU.utf8': 'c',
   });
} catch (exc) {
  console.error(exc);
}

  console.info('DP units are set successfully - ' + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:1845

***

<a id="dpsetwait" name="dpsetwait"></a>

### dpSetWait()

> **dpSetWait**(`dpeNames`, `values`): `Promise`\<`boolean`\>

Set the value of one or more datapoint element(s).

#### Parameters

• **dpeNames**: `string` \| `string`[]

Datapoint element name(s) of the values to set.

• **values**: `unknown`

Values to set. Must have the same size as __dpeNames__. If __dpeNames__ is a
              single string and not an array, this parameter must also be a single value
              and not an array.

#### Returns

`Promise`\<`boolean`\>

Promise that resolves to `true` if succesful. If not successful,
         a [WinccoaError](WinccoaError.md) wil be thrown instead.

`true` if successful, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.
> Since this method does not wait for the actual value update
> in the database, __the update can still fail__ after this method returned `true`. Use
[dpSetWait](WinccoaManager.md#dpsetwait) to also get informed about these errors.

#### Throws

[WinccoaError](WinccoaError.md) when DPE names do not exist, values cannot be converted, array
        sizes mismatch, no write access etc.

#### See

- [dpSet](WinccoaManager.md#dpset)
- [dpSetTimed](WinccoaManager.md#dpsettimed)
- [dpSetTimedWait](WinccoaManager.md#dpsettimedwait)
- [CTRL function `dpSetWait()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpSetWait.html)

#### Example

```ts
const dpes = ['ExampleDP_Arg1.', 'ExampleDP_DDE.b1'];
const values = [123.456, false];
try {
  await winccoa.dpSetWait(dpes, values); // Two arrays of size 2
  await winccoa.dpSetWait('ExampleDP_Arg2.', 2); // single value
} catch (exc) {
  console.error(exc);
}
```

#### Source

winccoa-manager/lib/binding.ts:895

***

<a id="dptypes" name="dptypes"></a>

### dpTypes()

> **dpTypes**(`pattern`, `systemId`, `includeEmpty`): `string`[]

Returns all or selected data point types from the current project.

#### Parameters

• **pattern**: `string`= `''`

Pattern for the returned DPTs. When an empty pattern is given (=default), then returns all DP types.
<br>Wildcards are used to filter data point type name.
The charcters `*` and `?` are used for the purpose,
where the asterisk (`*`) replaces any number of characters and the question mark `?` stands for just one character.
<br>Wildcards can be used in arrays (square brackets , e.g.: `[0,3,5-7]` - numbers 0,3,5,6,7) or outside arrays in option lists (in curly brackets `{}`).
<br>Example of wildcards in lists of options:
```
winccoa.dpTypes('{*.Ala.*,*.Ala*}');
winccoa.dpTypes('*{.Ala.,.Ala}*');
winccoa.dpTypes('*.A{la.,la}*');
winccoa.dpTypes('*.Al{a.,a}*');
winccoa.dpTypes('*.Ala{.,}*');
winccoa.dpTypes('*.Ala{.}*');
winccoa.dpTypes('*.Ala.*');
winccoa.dpTypes('*.Ala*');
```

• **systemId**: `number`= `-1`

The desired system if querying from other systems. Optional parameter.
                If this parameter is not defined, the own system is queried.

• **includeEmpty**: `boolean`= `true`

When this is set to false, data point types without existing
                    data points will be ignored.

#### Returns

`string`[]

String array with all DP type names.

#### Throws

[WinccoaError](WinccoaError.md) when invalid argument type or non-existing __systemId__ is given.

#### See

- [CTRL function `dpTypes()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlA_D/dpTypes.html)

#### Example

```ts
try {
  const foundDpTypes = winccoa.dpTypes('ExampleDP*', 1, true);
  for (let i = 0; i < foundDpTypes.length; i++) {
    console.info("DP type: " + foundDpTypes.at(i));
  }
} catch (exc) {
  console.error(exc);
}
```

#### Source

winccoa-manager/lib/binding.ts:764

***

<a id="exit" name="exit"></a>

### exit()

> **exit**(`exitCode`): `void`

Exits the WinCC OA manager.

#### Parameters

• **exitCode**: `number`= `0`

Exit code to return to the operating system.

#### Returns

`void`

#### Example

```ts
winccoa.exit();
```

#### Source

winccoa-manager/lib/binding.ts:590

***

<a id="findfile" name="findfile"></a>

### findFile()

> **findFile**(`fileDirName`): `string`

Search for file or directory in WinCC OA project and installation paths.

#### Parameters

• **fileDirName**: `string`

the file or directory to search for

#### Returns

`string`

full path of the file or directory or an empty string if not found

#### Throws

[WinccoaError](WinccoaError.md) when invalid argument type is given.

#### Example

```ts
let configPath;
try {
  configPath = winccoa.findFile('config/config');
} catch (exc) {
  console.error(exc);
}

console.info("Config file full path: " + configPath);
```

#### Source

winccoa-manager/lib/binding.ts:789

***

<a id="getoptions" name="getoptions"></a>

### getOptions()

> **getOptions**(): [`WinccoaOptions`](../interfaces/WinccoaOptions.md)

Returns all available options and their values.
The options can be set with [setOptions](WinccoaManager.md#setoptions).

#### Returns

[`WinccoaOptions`](../interfaces/WinccoaOptions.md)

Object containing all current option values.

#### See

- [setOptions](WinccoaManager.md#setoptions)
- [WinccoaOptions](../interfaces/WinccoaOptions.md)

#### Example

```ts
let options = winccoa.getOptions();
for (const [key, value] of Object.entries(options)) {
  console.info(`Name: ${key} - Value: ${value}`);
}
```

#### Source

winccoa-manager/lib/binding.ts:608

***

<a id="getpaths" name="getpaths"></a>

### getPaths()

> **getPaths**(): `string`[]

Returns list of project, sub-project and product installation paths.

#### Returns

`string`[]

List of project, sub-project and product installation paths.
The project path is always a first entry and the installation path is always the last.

#### Example

```ts
let paths = winccoa.getPaths();
for (let i = 0; i < paths.length; i++) {
  console.info(paths.at(i));
}
```

#### Source

winccoa-manager/lib/binding.ts:578

***

<a id="getsystemid" name="getsystemid"></a>

### getSystemId()

> **getSystemId**(`systemName`?): `number`

Returns the system ID.

#### Parameters

• **systemName?**: `string`

The name of the system (optional).
If it is not given, then the system ID of its own system will be returned.

#### Returns

`number`

The system ID.

#### Throws

[WinccoaError](WinccoaError.md) when invalid system name is given.

#### See

- [getSystemName](WinccoaManager.md#getsystemname)
- [CTRL function `getSystemId()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlE_R/getSystemId.html)

#### Example

```ts
let ownId;
let system1Id;
try {
  ownId = winccoa.getSystemId();
  system1Id = winccoa.getSystemId('System1:');
} catch (exc) {
  console.error(exc);
}

console.info("Own system id = " + ownId);
console.info("System1 id = " + system1Id);
```

#### Source

winccoa-manager/lib/binding.ts:1377

***

<a id="getsystemname" name="getsystemname"></a>

### getSystemName()

> **getSystemName**(`systemId`?): `string`

Returns the system name.

#### Parameters

• **systemId?**: `number`

System ID (optional).
If it is not given, then the system name of its own system will be returned.

#### Returns

`string`

The system name.

#### Throws

[WinccoaError](WinccoaError.md) when invalid system ID is given.

#### See

- [getSystemId](WinccoaManager.md#getsystemid)
- [CTRL function `getSystemName()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlE_R/getSystemName.html)

#### Example

```ts
try {
  const ownName = winccoa.getSystemName();
  const id1Name = winccoa.getSystemName(1);
  console.info(
    `Own system name = '${ownName}, system with id 1 name = '${id1Name}'`
  );
} catch (exc) {
  console.error(exc);
}
```

#### Source

winccoa-manager/lib/binding.ts:1404

***

<a id="getversioninfo" name="getversioninfo"></a>

### getVersionInfo()

> **getVersionInfo**(): [`WinccoaVersionDetails`](../interfaces/WinccoaVersionDetails.md)

Returns information about current API and WinCC OA versions.

#### Returns

[`WinccoaVersionDetails`](../interfaces/WinccoaVersionDetails.md)

#### Source

winccoa-manager/lib/binding.ts:650

***

<a id="isreduactive" name="isreduactive"></a>

### isReduActive()

> **isReduActive**(): `boolean`

Checks if the event manager to which this manager is connected is currently
the active REDU partner.

#### Returns

`boolean`

`true` if the event manager to which this manager is connected is
         currently the active REDU partner.

#### See

- [CTRL function `isReduActive()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlE_R/isReduActive.html)

#### Example

```ts
const isEventReduActive = winccoa.isReduActive();
console.info('Event currently is active - ' + isEventReduActive);
```

#### Source

winccoa-manager/lib/binding.ts:2111

***

<a id="isredundant" name="isredundant"></a>

### isRedundant()

> **isRedundant**(): `boolean`

Checks whether the project has been configured as redundant.

#### Returns

`boolean`

`true` if project has been configured as redundant.

#### See

- [CTRL function `isRedundant()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlE_R/isRedundant.html)

#### Example

```ts
const isProjectRedundant = winccoa.isRedundant();
console.info('My project is redundant - ' + isProjectRedundant);
```

#### Source

winccoa-manager/lib/binding.ts:2093

***

<a id="logfatal" name="logfatal"></a>

### logFatal()

> **logFatal**(...`args`): `void`

Writes a fatal error log entry. This also exits the WinCC OA manager.

#### Parameters

• ...**args**: `unknown`[]

Fatal error information to be written to log.

#### Returns

`void`

#### Example

```ts
let note = "Additional note.";
winccoa.logFatal("Fatal message", note);
```

#### Source

winccoa-manager/lib/binding.ts:562

***

<a id="loginfo" name="loginfo"></a>

### logInfo()

> **logInfo**(...`args`): `void`

Writes an information log entry. `console.log()` and `console.info()` are mapped
to this method.

#### Parameters

• ...**args**: `unknown`[]

Information to be written to log.

#### Returns

`void`

#### Example

```ts
let note = "Additional note.";
winccoa.logInfo("Info message", note);
```

#### Source

winccoa-manager/lib/binding.ts:523

***

<a id="logsevere" name="logsevere"></a>

### logSevere()

> **logSevere**(...`args`): `void`

Writes a severe error log entry. `console.error()` is mapped to this method.

#### Parameters

• ...**args**: `unknown`[]

Severe error information to be written to log.

#### Returns

`void`

#### Example

```ts
let note = "Additional note.";
winccoa.logSevere("Severe message", note);
```

#### Source

winccoa-manager/lib/binding.ts:549

***

<a id="logwarning" name="logwarning"></a>

### logWarning()

> **logWarning**(...`args`): `void`

Writes a warning log entry. `console.warn()` is mapped to this method.

#### Parameters

• ...**args**: `unknown`[]

Warning information to be written to log.

#### Returns

`void`

#### Example

```ts
let note = "Additional note.";
winccoa.logWarning("Warning message", note);
```

#### Source

winccoa-manager/lib/binding.ts:536

***

<a id="myreduhost" name="myreduhost"></a>

### myReduHost()

> **myReduHost**(): `string`

Returns the host name of the Event Manager this manager is connected to. Use this method only on redundant computers.

#### Returns

`string`

Host name of the Event Manager this manager is connected to.

#### See

- [CTRL function `myReduHost()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlE_R/myReduHost.html)

#### Example

```ts
const reduHostName = winccoa.myReduHost();
console.info('My redu host name - ' + reduHostName);
```

#### Source

winccoa-manager/lib/binding.ts:2060

***

<a id="myreduhostnum" name="myreduhostnum"></a>

### myReduHostNum()

> **myReduHostNum**(): `number`

Returns host number in a redundant system depending on the connection to the Event Manager - manager 1 or 2 (for example, eventHost = "host1$host2").
In a non-redundant configuration this always returns 1.

#### Returns

`number`

Host number.

#### See

- [CTRL function `myReduHostNum()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlE_R/myReduHostNum.html)

#### Example

```ts
const reduHostNumber = winccoa.myReduHostNum();
console.info('My redu host number - ' + reduHostNumber);
```

#### Source

winccoa-manager/lib/binding.ts:2077

***

<a id="securityevent" name="securityevent"></a>

### securityEvent()

> **securityEvent**(`id`, ...`args`): `void`

Reports a security event, this must be called whenever a security-relevant
action is made in JavaScript (like opening a server port).

#### Parameters

• **id**: [`WinccoaSecurityEventId`](../enumerations/WinccoaSecurityEventId.md)

ID of the security event.

• ...**args**: `unknown`[]

Arguments for the security event, depending on the value
            of id. See [WinccoaSecurityEventId](../enumerations/WinccoaSecurityEventId.md) for details.

#### Returns

`void`

#### Throws

[WinccoaError](WinccoaError.md) when id is not known, required arguments
        are missing in args.

#### See

[WinccoaSecurityEventId](../enumerations/WinccoaSecurityEventId.md)

#### Example

```ts
import { WinccoaManager, WinccoaSecurityEventId } from 'winccoa-manager';
const winccoa = new WinccoaManager();

winccoa.securityEvent(WinccoaSecurityEventId.PortOpened, 8443, 'https://');
```

#### Source

winccoa-manager/lib/binding.ts:1789

***

<a id="setoptions" name="setoptions"></a>

### setOptions()

> **setOptions**(`obj`): `boolean`

Set one or more options.
The options and their values can be retrieved with [getOptions](WinccoaManager.md#getoptions).

#### Parameters

• **obj**: `Partial`\<`Omit`\<[`WinccoaOptions`](../interfaces/WinccoaOptions.md), `"userId"`\>\>

The options to be set (see [WinccoaOptions](../interfaces/WinccoaOptions.md) for possible options).

#### Returns

`boolean`

Boolean `true` on success, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.

#### Note

The userId option cannot be set with this method.
<br>The user can be set with [setUserId](WinccoaManager.md#setuserid) for the instance of `WinccoaManager`.
<br>The user can be set with `-user` manager option for the node manager,
see [Administration of managers](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Pmon_Consolepanel/Pmon_Consolepanel-23.html).

#### Throws

[WinccoaError](WinccoaError.md) if option has wrong type or option value is out of range.

#### See

- [getOptions](WinccoaManager.md#getoptions)
- [WinccoaOptions](../interfaces/WinccoaOptions.md)
- [setUserId](WinccoaManager.md#setuserid)
- [Administration of managers](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/Pmon_Consolepanel/Pmon_Consolepanel-23.html)

#### Example

```ts
import { WinccoaManager, WinccoaLangTextFormat } from 'winccoa-manager';
const winccoa = new WinccoaManager();

function setOptionsTest() {
  try {
    winccoa.setOptions({
      langTextFormat: WinccoaLangTextFormat.StringFixed,
      langIdx: 1,
    });
  } catch (exc) {
    console.error(exc);
  }
}
```

#### Source

winccoa-manager/lib/binding.ts:643

***

<a id="setuserid" name="setuserid"></a>

### setUserId()

> **setUserId**(`id`, `password`?): `boolean`

Sets the current user ID to the specified value for the current instance of `WinccoaManager`.

#### Parameters

• **id**: `number`

User ID to set.

• **password?**: `string`

Password to use to set user (not needed if manager started as root).

#### Returns

`boolean`

Boolean `true` in case of a success, otherwise [WinccoaError](WinccoaError.md) wil be thrown instead.

#### Throws

[WinccoaError](WinccoaError.md) when __id__ is not found or invalid.

#### See

- [CTRL function `setUserId()`](https://www.winccoa.com/documentation/WinCCOA/latest/en_US/ControlS_Z/setUserId.html)

#### Example

```ts
let isSuccess = false;
try {
  isSuccess = winccoa.setUserId(2048);  // operatorAll user id
} catch (exc) {
  console.error(exc);
}

console.info('User id is set to operatorAll user id successfully - ' + isSuccess);
```

#### Source

winccoa-manager/lib/binding.ts:1765
