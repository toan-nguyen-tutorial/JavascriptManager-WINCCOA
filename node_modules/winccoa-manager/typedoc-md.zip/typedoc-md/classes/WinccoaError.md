[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaError

# Class: WinccoaError

Error class that contains additional information found in WinCC OA errors, like
the WinCC OA error code.

## Examples

```ts
import { WinccoaManager, WinccoaError } from 'winccoa-manager';
const winccoa = new WinccoaManager();

try {
   ...
} catch(exc) {
  // standard reporting
  console.error(exc);

  // access the details
  var oaError = exc as WinccoaError;
  console.warn('Error code    : ' + oaError.code);
  console.warn('Error message : ' + oaError.message);
  console.warn('Catalogue     : ' + oaError.catalog);
  console.warn('Details       : ' + oaError.details);
}
```

```js
const { WinccoaManager } = require('winccoa-manager');
const winccoa = new WinccoaManager();

try {
   ...
} catch(exc) {
  // standard reporting
  console.error(exc);

  // access the details
  console.warn('Error code    : ' + exc.code);
  console.warn('Error message : ' + exc.message);
  console.warn('Catalogue     : ' + exc.catalog);
  console.warn('Details       : ' + exc.details);
}
```

## Extends

- `Error`

## Constructors

<a id="constructors" name="constructors"></a>

### new WinccoaError()

> **new WinccoaError**(`code`, `message`, `catalog`, `details`?): [`WinccoaError`](WinccoaError.md)

Constructor. This constructor is also used by the [WinccoaManager](WinccoaManager.md) to create
[WinccoaError](WinccoaError.md) instances.

#### Parameters

• **code**: `string` \| `number`

WincCC OA error code. This can either be a number (like 71 for "DP does
            not exist") or a string. The meaning of string error codes can be found
            in the corresponding __catalog__.

• **message**: `string`

Error message corresponding to __code__.

• **catalog**: `string`= `''`

Name of the error catalog where the error message can be found. If
               empty, this refers to catalog `_errors.cat`.

• **details?**: `unknown`

Additional details specific to that error. Not all errors provide
               this information.

#### Returns

[`WinccoaError`](WinccoaError.md)

#### Overrides

`Error.constructor`

#### Source

winccoa-manager/lib/error.ts:55

## Properties

<a id="catalog" name="catalog"></a>

### catalog

> **catalog**: `string` = `''`

Name of the error catalog where the error message can be found. If
               empty, this refers to catalog `_errors.cat`.

#### Source

winccoa-manager/lib/error.ts:58

***

<a id="code" name="code"></a>

### code

> **code**: `string` \| `number`

WincCC OA error code. This can either be a number (like 71 for "DP does
            not exist") or a string. The meaning of string error codes can be found
            in the corresponding __catalog__.

#### Source

winccoa-manager/lib/error.ts:56

***

<a id="details" name="details"></a>

### details?

> `optional` **details**: `unknown`

Additional details specific to that error. Not all errors provide
               this information.

#### Source

winccoa-manager/lib/error.ts:59

***

<a id="message" name="message"></a>

### message

> **message**: `string`

#### Inherited from

`Error.message`

#### Source

node\_modules/typescript/lib/lib.es5.d.ts:1077

***

<a id="name" name="name"></a>

### name

> **name**: `string`

#### Inherited from

`Error.name`

#### Source

node\_modules/typescript/lib/lib.es5.d.ts:1076

***

<a id="stack" name="stack"></a>

### stack?

> `optional` **stack**: `string`

#### Inherited from

`Error.stack`

#### Source

node\_modules/typescript/lib/lib.es5.d.ts:1078

***

<a id="preparestacktrace" name="preparestacktrace"></a>

### prepareStackTrace()?

> `static` `optional` **prepareStackTrace**: (`err`, `stackTraces`) => `any`

Optional override for formatting stack traces

#### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

#### Parameters

• **err**: `Error`

• **stackTraces**: `CallSite`[]

#### Returns

`any`

#### Inherited from

`Error.prepareStackTrace`

#### Source

node\_modules/@types/node/globals.d.ts:28

***

<a id="stacktracelimit" name="stacktracelimit"></a>

### stackTraceLimit

> `static` **stackTraceLimit**: `number`

#### Inherited from

`Error.stackTraceLimit`

#### Source

node\_modules/@types/node/globals.d.ts:30

## Methods

<a id="capturestacktrace" name="capturestacktrace"></a>

### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt`?): `void`

Create .stack property on a target object

#### Parameters

• **targetObject**: `object`

• **constructorOpt?**: `Function`

#### Returns

`void`

#### Inherited from

`Error.captureStackTrace`

#### Source

node\_modules/@types/node/globals.d.ts:21
