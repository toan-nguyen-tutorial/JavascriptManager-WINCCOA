[**winccoa-manager**](../README.md) • **Docs**

***

[winccoa-manager](../globals.md) / WinccoaAlertTime

# Class: WinccoaAlertTime

Time of the alarm, with extra index for several simultaneous alarms

## Constructors

<a id="constructors" name="constructors"></a>

### new WinccoaAlertTime()

> **new WinccoaAlertTime**(`date`, `count`, `dpe`): [`WinccoaAlertTime`](WinccoaAlertTime.md)

Constructor.

#### Parameters

• **date**: `Date`

Time of alarm occurrence

• **count**: `number`

Serial number

• **dpe**: `string`

Data point element name

#### Returns

[`WinccoaAlertTime`](WinccoaAlertTime.md)

#### See

- [WinccoaManager.alertSet](WinccoaManager.md#alertset)
- [WinccoaManager.alertSetWait](WinccoaManager.md#alertsetwait)
- [WinccoaManager.alertSetTimed](WinccoaManager.md#alertsettimed)
- [WinccoaManager.alertSetTimedWait](WinccoaManager.md#alertsettimedwait)

#### Example

#### TypeScript
``` ts
import { WinccoaManager, WinccoaAlertTime } from 'winccoa-manager';
const winccoa = new WinccoaManager();

async function alertTest() {
  const dpeWithAlert = 'ExampleDP_AlertHdl1.'; // assuming alert is triggered
  const result = await winccoa.dpQuery(
    "SELECT ALERT '_alert_hdl.._act_state', '_alert_hdl.._value' FROM '" +
      dpeWithAlert +
      "'",
  );

  const ts = result[result.length - 1][1] as WinccoaAlertTime;
  const alertTime = new WinccoaAlertTime(
    ts.date,
    ts.count,
    ts.dpe + '._comment',
  );
}
```
#### JavaScript
``` js
const { WinccoaManager, WinccoaAlertTime } = require('winccoa-manager');
const winccoa = new WinccoaManager();

async function alertTest() {
  const dpeWithAlert = 'ExampleDP_AlertHdl1.'; // assuming alert is triggered
  const result = await winccoa.dpQuery(
    "SELECT ALERT '_alert_hdl.._act_state', '_alert_hdl.._value' FROM '" +
      dpeWithAlert +
      "'",
  );

  const ts = result[result.length - 1][1];
  const alertTime = new WinccoaAlertTime(
    ts.date,
    ts.count,
    ts.dpe + '._comment',
  );
}
```

#### Source

winccoa-manager/lib/alerttime.ts:58

## Properties

<a id="count" name="count"></a>

### count

> **count**: `number`

Serial number

#### Source

winccoa-manager/lib/alerttime.ts:60

***

<a id="date" name="date"></a>

### date

> **date**: `Date`

Time of alarm occurrence

#### Source

winccoa-manager/lib/alerttime.ts:59

***

<a id="dpe" name="dpe"></a>

### dpe

> **dpe**: `string`

Data point element name

#### Source

winccoa-manager/lib/alerttime.ts:61
